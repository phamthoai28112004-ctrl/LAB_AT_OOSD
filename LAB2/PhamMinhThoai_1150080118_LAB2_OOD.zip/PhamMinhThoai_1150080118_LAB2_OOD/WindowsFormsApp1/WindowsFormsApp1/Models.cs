﻿using System;

namespace QuanLyThuVien.Models
{
    // 0. Class Trả về Kết quả xử lý
    public class KetQuaXuLy
    {
        public bool ThanhCong { get; set; }
        public string ThongBao { get; set; }
        public object DuLieu { get; set; }

        public static KetQuaXuLy Ok(string thongBao = "Thành công.", object duLieu = null)
        {
            return new KetQuaXuLy { ThanhCong = true, ThongBao = thongBao, DuLieu = duLieu };
        }

        public static KetQuaXuLy Loi(string thongBao)
        {
            return new KetQuaXuLy { ThanhCong = false, ThongBao = thongBao, DuLieu = null };
        }
    }

    // 1. Model Nhân viên (Đã đồng bộ MaNhanVien / MaNV và SoDienThoai / DienThoai)
    public class NhanVien
    {
        public string MaNhanVien { get; set; }
        public string MaNV
        {
            get => MaNhanVien;
            set => MaNhanVien = value;
        }

        public string Ho { get; set; }
        public string Ten { get; set; }
        public string Phai { get; set; }
        public DateTime? NgaySinh { get; set; }
        public string ChucVu { get; set; }

        public string SoDienThoai { get; set; }
        public string DienThoai
        {
            get => SoDienThoai;
            set => SoDienThoai = value;
        }

        public string HoTen => $"{Ho} {Ten}".Trim();
    }

    // 2. Model Thể loại
    public class TheLoai
    {
        public string MaTheLoai { get; set; }
        public string TenTheLoai { get; set; }
    }

    // 3. Model Nhà xuất bản (Đã đồng bộ MaNhaXuatBan / MaNXB và SoDienThoai / DienThoai)
    public class NhaXuatBan
    {
        public string MaNhaXuatBan { get; set; }
        public string MaNXB
        {
            get => MaNhaXuatBan;
            set => MaNhaXuatBan = value;
        }

        public string TenNXB { get; set; }
        public string DiaChi { get; set; }

        public string SoDienThoai { get; set; }
        public string DienThoai
        {
            get => SoDienThoai;
            set => SoDienThoai = value;
        }

        public string Email { get; set; }
    }

    // 4. Model Sách & Đầu sách
    public class Sach
    {
        public string MaSach { get; set; }
        public string TenSach { get; set; }
        public string TacGia { get; set; }
        public string MaTheLoai { get; set; }
        public string MaNXB { get; set; }
        public int NamXuatBan { get; set; }
        public int SoLuong { get; set; }
        public decimal DonGia { get; set; }
    }

    public class DauSach
    {
        public string MaDauSach { get; set; }
        public string TenDauSach { get; set; }
        public string TacGia { get; set; }
        public string MaTheLoai { get; set; }
        public string TenTheLoai { get; set; }
        public string MaNXB { get; set; }
        public int SoLuongHienCo { get; set; }
        public int SoLuongConLoi { get; set; }
        public string TenSach { get; internal set; }
        public int NamXuatBan { get; internal set; }
        public string MaNhaXuatBan { get; internal set; }
    }

    // 5. Model Độc giả
    public class DocGia
    {
        public string MaDocGia { get; set; }
        public string Ho { get; set; }
        public string Ten { get; set; }
        public string Phai { get; set; }
        public DateTime? NgaySinh { get; set; }

        public string SoDienThoai { get; set; }
        public string DienThoai
        {
            get => SoDienThoai;
            set => SoDienThoai = value;
        }

        public string DiaChi { get; set; }
        public string Email { get; set; }
        public string Anh3x4 { get; set; }
        public DateTime? NgayLapThe { get; set; }
        public DateTime? NgayHetHan { get; set; }

        public string HoTen => !string.IsNullOrEmpty(Ho) ? $"{Ho} {Ten}".Trim() : (Ten ?? "");
    }

    // 6. Model Phiếu mượn
    public class PhieuMuon
    {
        public string MaPhieuMuon { get; set; }
        public string MaDocGia { get; set; }
        public string MaNV { get; set; }
        public string MaNhanVien
        {
            get => MaNV;
            set => MaNV = value;
        }
        public DateTime NgayMuon { get; set; }
        public DateTime NgayHenTra { get; set; }
        public string TinhTrang { get; set; }
    }

    // 7. Model Chi tiết phiếu mượn
    public class ChiTietPhieuMuon
    {
        public string MaPhieuMuon { get; set; }
        public string MaSach { get; set; }
        public int SoLuong { get; set; }
        public DateTime? NgayTra { get; set; }
        public string GhiChu { get; set; }
    }

    // 8. Model Thống kê tổng hợp
    public class ThongKeTongHop
    {
        public int TongSoSach { get; set; }
        public int TongSoDocGia { get; set; }
        public int TongLuotMuon { get; set; }
        public int TongLuotQuaHan { get; set; }
        public decimal TongTienPhat { get; set; }
    }
}