﻿namespace QuanLyThuVien.Forms
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnDanhMuc;
        private System.Windows.Forms.Button btnSach;
        private System.Windows.Forms.Button btnDocGia;
        private System.Windows.Forms.Button btnMuonTra;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.Button btnThoat;

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnDanhMuc = new System.Windows.Forms.Button();
            this.btnSach = new System.Windows.Forms.Button();
            this.btnDocGia = new System.Windows.Forms.Button();
            this.btnMuonTra = new System.Windows.Forms.Button();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.Text = "HỆ THỐNG QUẢN LÝ THƯ VIỆN";
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Location = new System.Drawing.Point(0, 40);
            this.lblTitle.Size = new System.Drawing.Size(780, 60);
            this.lblTitle.Name = "lblTitle";

            // btnDanhMuc
            this.btnDanhMuc.Text = "Danh mục / Nhân viên";
            this.btnDanhMuc.Size = new System.Drawing.Size(240, 60);
            this.btnDanhMuc.Location = new System.Drawing.Point(120, 150);
            this.btnDanhMuc.Name = "btnDanhMuc";
            this.btnDanhMuc.Click += new System.EventHandler(this.btnDanhMuc_Click);

            // btnSach
            this.btnSach.Text = "Quản lý đầu sách";
            this.btnSach.Size = new System.Drawing.Size(240, 60);
            this.btnSach.Location = new System.Drawing.Point(420, 150);
            this.btnSach.Name = "btnSach";
            this.btnSach.Click += new System.EventHandler(this.btnSach_Click);

            // btnDocGia
            this.btnDocGia.Text = "Độc giả và thẻ";
            this.btnDocGia.Size = new System.Drawing.Size(240, 60);
            this.btnDocGia.Location = new System.Drawing.Point(120, 230);
            this.btnDocGia.Name = "btnDocGia";
            this.btnDocGia.Click += new System.EventHandler(this.btnDocGia_Click);

            // btnMuonTra
            this.btnMuonTra.Text = "Mượn - Trả sách";
            this.btnMuonTra.Size = new System.Drawing.Size(240, 60);
            this.btnMuonTra.Location = new System.Drawing.Point(420, 230);
            this.btnMuonTra.Name = "btnMuonTra";
            this.btnMuonTra.Click += new System.EventHandler(this.btnMuonTra_Click);

            // btnThongKe
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.Size = new System.Drawing.Size(240, 60);
            this.btnThongKe.Location = new System.Drawing.Point(120, 310);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);

            // btnThoat
            this.btnThoat.Text = "Thoát";
            this.btnThoat.Size = new System.Drawing.Size(240, 60);
            this.btnThoat.Location = new System.Drawing.Point(420, 310);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);

            // FrmMain
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 450);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnDanhMuc);
            this.Controls.Add(this.btnSach);
            this.Controls.Add(this.btnDocGia);
            this.Controls.Add(this.btnMuonTra);
            this.Controls.Add(this.btnThongKe);
            this.Controls.Add(this.btnThoat);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý thư viện";
            this.ResumeLayout(false);
        }
    }
}