﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyThuVien.Data
{
    public static class Db
    {
        // 1. Lấy chuỗi kết nối từ App.config
        public static string ConnectionString
        {
            get
            {
                var settings = ConfigurationManager.ConnectionStrings["QuanLyThuVienDb"];
                if (settings == null)
                {
                    throw new Exception("Chưa cấu hình chuỗi kết nối 'QuanLyThuVienDb' trong file App.config!");
                }
                return settings.ConnectionString;
            }
        }

        // 2. Mở kết nối SQL
        public static SqlConnection OpenConnection()
        {
            SqlConnection cn = new SqlConnection(ConnectionString);
            cn.Open();
            return cn;
        }

        #region TRUY VẤN SQL THUẦN (Text Queries)

        // Lấy dữ liệu lên DataGridView / ComboBox (Lệnh SELECT)
        public static DataTable Query(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                AttachParameters(cmd, parameters);
                DataTable table = new DataTable();
                da.Fill(table);
                return table;
            }
        }

        // Thực thi Thêm / Sửa / Xóa (INSERT, UPDATE, DELETE) -> Trả về số dòng bị ảnh hưởng
        public static int Execute(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                AttachParameters(cmd, parameters);
                return cmd.ExecuteNonQuery();
            }
        }

        // Lấy 1 giá trị duy nhất (COUNT, MAX, SUM, ID vừa tạo...)
        public static object Scalar(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                AttachParameters(cmd, parameters);
                return cmd.ExecuteScalar();
            }
        }

        #endregion

        #region XỬ LÝ TRANSACTION (QUAN TRỌNG CHO NGHIỆP VỤ MƯỢN / TRẢ SÁCH)

        // Thực thi chuỗi nhiều câu lệnh SQL trong 1 giao dịch. 
        // Nếu 1 câu lệnh lỗi -> Tự động Rollback hủy bỏ toàn bộ.
        public static bool ExecuteTransaction(List<Tuple<string, SqlParameter[]>> commandList)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlTransaction tran = cn.BeginTransaction())
            {
                try
                {
                    foreach (var item in commandList)
                    {
                        using (SqlCommand cmd = new SqlCommand(item.Item1, cn, tran))
                        {
                            AttachParameters(cmd, item.Item2);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tran.Commit(); // Lưu tất cả thay đổi
                    return true;
                }
                catch (Exception ex)
                {
                    tran.Rollback(); // Hoàn tác nếu có bất kỳ lỗi nào
                    throw new Exception("Lỗi Transaction: " + ex.Message);
                }
            }
        }

        #endregion

        #region TRUY VẤN STORED PROCEDURE (Nếu bài Lab yêu cầu)

        public static DataTable QuerySP(string spName, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(spName, cn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                AttachParameters(cmd, parameters);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataTable table = new DataTable();
                    da.Fill(table);
                    return table;
                }
            }
        }

        public static int ExecuteSP(string spName, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(spName, cn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                AttachParameters(cmd, parameters);
                return cmd.ExecuteNonQuery();
            }
        }

        #endregion

        #region HÀM BỔ TRỢ AN TOÀN DỮ LIỆU

        // Tự động kiểm tra & gắn tham số, xử lý lỗi NULL trong SQL
        private static void AttachParameters(SqlCommand cmd, SqlParameter[] parameters)
        {
            if (parameters != null && parameters.Length > 0)
            {
                cmd.Parameters.Clear();
                foreach (var p in parameters)
                {
                    if (p != null)
                    {
                        // Nếu giá trị truyền vào là null thì tự chuyển thành DBNull.Value của SQL
                        if (p.Value == null)
                        {
                            p.Value = DBNull.Value;
                        }
                        cmd.Parameters.Add(p);
                    }
                }
            }
        }

        // Hàm rút gọn tạo SqlParameter
        public static SqlParameter Para(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        #endregion
    }
}