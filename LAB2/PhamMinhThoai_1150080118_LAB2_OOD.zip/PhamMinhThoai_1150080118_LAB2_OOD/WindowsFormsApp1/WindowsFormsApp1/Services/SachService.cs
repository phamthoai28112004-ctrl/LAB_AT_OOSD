﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyThuVien.Data;
using QuanLyThuVien.Models;

namespace QuanLyThuVien.Services
{
    public class SachService
    {
        public DataTable LayDanhSach(string tuKhoa = "")
        {
            string sql = @"SELECT s.MaDauSach, s.TenSach, s.NamXuatBan, s.SoLuongHienCo, 
                                  s.MaTheLoai, t.TenTheLoai, s.MaNhaXuatBan
                           FROM DauSach s
                           LEFT JOIN TheLoai t ON s.MaTheLoai = t.MaTheLoai
                           WHERE s.MaDauSach LIKE @TK OR s.TenSach LIKE @TK
                           ORDER BY s.MaDauSach";

            return Db.Query(sql, new SqlParameter("@TK", $"%{tuKhoa}%"));
        }

        // Phương thức lấy danh sách các sách còn trong kho để phục vụ mượn sách
        public DataTable LaySachConTrongKho()
        {
            string sql = @"SELECT MaDauSach, TenSach, NamXuatBan, SoLuongHienCo 
                           FROM DauSach 
                           WHERE SoLuongHienCo > 0 
                           ORDER BY MaDauSach";

            return Db.Query(sql);
        }

        // Chỉ giữ lại 1 phương thức Luu này duy nhất
        public KetQuaXuLy Luu(DauSach ds, bool capNhat)
        {
            if (ds == null || string.IsNullOrWhiteSpace(ds.MaDauSach) || string.IsNullOrWhiteSpace(ds.TenSach))
                return KetQuaXuLy.Loi("Mã đầu sách và tên sách không được để trống.");

            try
            {
                string sql = capNhat
                    ? @"UPDATE DauSach 
                        SET TenSach=@Ten, NamXuatBan=@Nam, SoLuongHienCo=@SL, MaTheLoai=@TL, MaNhaXuatBan=@NXB 
                        WHERE MaDauSach=@Ma"
                    : @"INSERT INTO DauSach(MaDauSach, TenSach, NamXuatBan, SoLuongHienCo, MaTheLoai, MaNhaXuatBan) 
                        VALUES(@Ma, @Ten, @Nam, @SL, @TL, @NXB)";

                int n = Db.Execute(sql,
                    new SqlParameter("@Ma", ds.MaDauSach.Trim()),
                    new SqlParameter("@Ten", ds.TenSach.Trim()),
                    new SqlParameter("@Nam", ds.NamXuatBan),
                    new SqlParameter("@SL", ds.SoLuongHienCo),
                    new SqlParameter("@TL", (object)(ds.MaTheLoai ?? string.Empty)),
                    new SqlParameter("@NXB", (object)(ds.MaNhaXuatBan ?? string.Empty)));

                return n > 0
                    ? KetQuaXuLy.Ok(capNhat ? "Cập nhật đầu sách thành công." : "Thêm đầu sách thành công.")
                    : KetQuaXuLy.Loi("Không có dữ liệu nào được thay đổi.");
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627 || ex.Number == 2601)
                    return KetQuaXuLy.Loi("Mã đầu sách đã tồn tại trong hệ thống.");

                return KetQuaXuLy.Loi("Lỗi cơ sở dữ liệu: " + ex.Message);
            }
        }

        public KetQuaXuLy Xoa(string maDauSach)
        {
            if (string.IsNullOrWhiteSpace(maDauSach))
                return KetQuaXuLy.Loi("Mã đầu sách không hợp lệ.");

            try
            {
                int n = Db.Execute("DELETE FROM DauSach WHERE MaDauSach = @Ma", new SqlParameter("@Ma", maDauSach.Trim()));
                return n > 0 ? KetQuaXuLy.Ok("Xóa đầu sách thành công.") : KetQuaXuLy.Loi("Không tìm thấy đầu sách để xóa.");
            }
            catch (SqlException ex)
            {
                if (ex.Number == 547)
                    return KetQuaXuLy.Loi("Không thể xóa sách này vì đã có cuốn sách/phiếu mượn liên quan.");

                return KetQuaXuLy.Loi("Lỗi cơ sở dữ liệu: " + ex.Message);
            }
        }
    }
}