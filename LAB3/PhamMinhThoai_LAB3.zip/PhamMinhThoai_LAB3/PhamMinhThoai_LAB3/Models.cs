﻿using System;

namespace QuanLyKhachSan.Models
{
    // 1. Bảng NhanVien
    public class NhanVien
    {
        public string MaNV { get; set; }
        public string HoTen { get; set; }
        public string VaiTro { get; set; }
        public string SoDienThoai { get; set; }
    }

    // 2. Bảng KhuVuc
    public class KhuVuc
    {
        public string MaKhuVuc { get; set; }
        public string TenKhuVuc { get; set; }
    }

    // 3. Bảng Phong
    public class Phong
    {
        public string SoPhong { get; set; }
        public string MaKhuVuc { get; set; }
        public int SoNguoiToiDa { get; set; }
        public decimal DonGiaNgay { get; set; }
        public string TrangThai { get; set; }
    }

    // 4. Bảng LoaiTienNghi
    public class LoaiTienNghi
    {
        public string MaLoaiTN { get; set; }
        public string TenLoaiTN { get; set; }
    }

    // 5. Bảng TienNghi
    public class TienNghi
    {
        public string MaTienNghi { get; set; }
        public string MaLoaiTN { get; set; }
        public int SoThuTu { get; set; }
        public string TinhTrangHienTai { get; set; }
    }

    // 6. Bảng PhieuLapDat
    public class PhieuLapDat
    {
        public string SoPhieuLapDat { get; set; }
        public string MaTienNghi { get; set; }
        public string SoPhong { get; set; }
        public DateTime NgayLap { get; set; }
        public string TinhTrang { get; set; }
        public string MaNV { get; set; }
        public string GhiChu { get; set; }
    }

    // 7. Bảng KhachHang
    public class KhachHang
    {
        public string MaKhach { get; set; }
        public string HoTen { get; set; }
        public string SoCMND { get; set; }
        public string QuocTich { get; set; }
        public string SoDienThoai { get; set; }
    }

    // 8. Bảng PhieuDatPhong
    public class PhieuDatPhong
    {
        public string SoPhieuDat { get; set; }
        public string MaKhach { get; set; }
        public string MaNVLeTan { get; set; }
        public DateTime NgayLap { get; set; }
        public DateTime NgayNhan { get; set; }
        public DateTime NgayTraDuKien { get; set; }
        public decimal TienCoc { get; set; }
        public string KenhDat { get; set; }
        public string TrangThai { get; set; }
        public DateTime? NgayNhanThucTe { get; set; }
        public DateTime? NgayTraThucTe { get; set; }
    }

    // 9. Bảng ChiTietDatPhong
    public class ChiTietDatPhong
    {
        public string SoPhieuDat { get; set; }
        public string SoPhong { get; set; }
        public int SoNguoi { get; set; }
    }

    // 10. Bảng NguoiLuuTru
    public class NguoiLuuTru
    {
        public int MaNguoiLT { get; set; }
        public string SoPhieuDat { get; set; }
        public string SoPhong { get; set; }
        public string HoTen { get; set; }
        public string SoCMND { get; set; }
        public string QuocTich { get; set; }
    }

    // 11. Bảng DichVu
    public class DichVu
    {
        public string MaDV { get; set; }
        public string TenDV { get; set; }
        public string DonViTinh { get; set; }
        public decimal DonGia { get; set; }
    }

    // 12. Bảng PhieuSuDungDV
    public class PhieuSuDungDV
    {
        public string SoPhieuSDDV { get; set; }
        public string SoPhieuDat { get; set; }
        public string SoPhong { get; set; }
        public DateTime NgaySuDung { get; set; }
        public string MaNV { get; set; }
    }

    // 13. Bảng ChiTietPhieuSuDungDV
    public class ChiTietPhieuSuDungDV
    {
        public string SoPhieuSDDV { get; set; }
        public string MaDV { get; set; }
        public int SoLuong { get; set; }
        public decimal DonGia { get; set; }
        public decimal ThanhTien { get; set; } // Cột tính toán (SoLuong * DonGia)
    }

    // 14. Bảng QuyDinhDenBu
    public class QuyDinhDenBu
    {
        public string MaQuyDinh { get; set; }
        public string MaLoaiTN { get; set; }
        public string MucDoThietHai { get; set; }
        public decimal MucDenBu { get; set; }
    }

    // 15. Bảng PhieuDenBu
    public class PhieuDenBu
    {
        public string SoPhieuDenBu { get; set; }
        public string SoPhieuDat { get; set; }
        public string SoPhong { get; set; }
        public DateTime NgayLap { get; set; }
        public string MaNV { get; set; }
        public decimal TongTien { get; set; }
    }

    // 16. Bảng ChiTietPhieuDenBu
    public class ChiTietPhieuDenBu
    {
        public string SoPhieuDenBu { get; set; }
        public string MaTienNghi { get; set; }
        public string MucDoThietHai { get; set; }
        public decimal SoTien { get; set; }
    }

    // 17. Bảng HoaDon
    public class HoaDon
    {
        public string SoHoaDon { get; set; }
        public string SoPhieuDat { get; set; }
        public DateTime NgayLap { get; set; }
        public string MaNV { get; set; }
        public int SoNgayTinhTien { get; set; }
        public decimal TienPhong { get; set; }
        public decimal TienDichVu { get; set; }
        public decimal TongTien { get; set; } // Cột tính toán (TienPhong + TienDichVu)
        public string TrangThai { get; set; }
    }

    // 18. Bảng ThanhToan
    public class ThanhToan
    {
        public string MaThanhToan { get; set; }
        public string SoHoaDon { get; set; }
        public DateTime NgayThanhToan { get; set; }
        public string HinhThuc { get; set; }
        public decimal SoTien { get; set; }
    }
}