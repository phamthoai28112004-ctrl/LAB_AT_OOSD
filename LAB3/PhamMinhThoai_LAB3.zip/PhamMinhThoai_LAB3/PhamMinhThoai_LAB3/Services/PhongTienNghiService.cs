﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyKhachSan.Services
{
    public class PhongTienNghiService
    {
        // 📌 CẤU HÌNH CHUỖI KẾT NỐI DATABASE:
        // Nếu dùng SQL Express mặc định: @"Data Source=.\SQLEXPRESS;Initial Catalog=QuanLyKhachSan;Integrated Security=True"
        // Nếu dùng SQL Server đầy đủ: @"Data Source=.;Initial Catalog=QuanLyKhachSan;Integrated Security=True"
        // Nếu dùng LocalDB: @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=QuanLyKhachSan;Integrated Security=True"

        private readonly string _connectionString = @"Data Source=PHAMMINHTHOAI\THOAI;Initial Catalog=QuanLyKhachSan;Integrated Security=True;TrustServerCertificate=True";

        /// <summary>
        /// Lấy danh sách phòng (Khớp đúng tên cột trong Database SQL của bạn)
        /// </summary>
        public DataTable LayDanhSachPhong()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"SELECT 
                                    p.SoPhong AS [Phong], 
                                    k.TenKhuVuc AS [Khu], 
                                    p.SoNguoiToiDa AS [SucChua], 
                                    p.DonGiaNgay AS [DonGia], 
                                    p.TrangThai 
                                FROM Phong p
                                INNER JOIN KhuVuc k ON p.MaKhuVuc = k.MaKhuVuc";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Lấy danh sách tiện nghi
        /// </summary>
        public DataTable LayDanhSachTienNghi()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"SELECT 
                                    t.MaTienNghi AS [Mã tiện nghi], 
                                    l.TenLoaiTN AS [Loại tiện nghi], 
                                    t.SoThuTu AS [Số thứ tự], 
                                    t.TinhTrangHienTai AS [Tình trạng]
                                FROM TienNghi t
                                INNER JOIN LoaiTienNghi l ON t.MaLoaiTN = l.MaLoaiTN";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Lấy danh sách phiếu lắp đặt
        /// </summary>
        public DataTable LayDanhSachLapDat()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"SELECT 
                                    SoPhieuLapDat AS [Số phiếu], 
                                    MaTienNghi AS [Mã tiện nghi], 
                                    SoPhong AS [Phòng], 
                                    NgayLap AS [Ngày lập], 
                                    TinhTrang AS [Tình trạng], 
                                    MaNV AS [Mã NV]
                                FROM PhieuLapDat";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Lập phiếu lắp đặt mới
        /// </summary>
        public bool LapPhieuLapDat(string maPhieu, string maTN, string maPhong, string tinhTrang)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"INSERT INTO PhieuLapDat (SoPhieuLapDat, MaTienNghi, SoPhong, NgayLap, TinhTrang, MaNV)
                                VALUES (@SoPhieu, @MaTN, @SoPhong, @NgayLap, @TinhTrang, @MaNV)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoPhieu", maPhieu);
                    cmd.Parameters.AddWithValue("@MaTN", maTN);
                    cmd.Parameters.AddWithValue("@SoPhong", maPhong);
                    cmd.Parameters.AddWithValue("@NgayLap", DateTime.Now.Date);
                    cmd.Parameters.AddWithValue("@TinhTrang", tinhTrang);
                    cmd.Parameters.AddWithValue("@MaNV", "NV01"); // Sử dụng NV01 đã có trong file SQL mẫu

                    conn.Open();
                    int result = cmd.ExecuteNonQuery();
                    return result > 0;
                }
            }
        }
    }
}