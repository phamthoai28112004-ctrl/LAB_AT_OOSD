﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyKhachSan.Services
{
    public class ThongKeService
    {
        private readonly string _connectionString = @"Data Source=PHAMMINHTHOAI\THOAI;Initial Catalog=QuanLyKhachSan;Integrated Security=True;TrustServerCertificate=True";

        /// <summary>
        /// Lấy các chỉ số thống kê tổng quan (Phiếu đặt, Đang ở, Hóa đơn, Doanh thu, Đền bù)
        /// </summary>
        public DataTable LayThongKeTongQuan(DateTime tuNgay, DateTime denNgay)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                // Đảm bảo lấy hết thời gian trong ngày đến (23:59:59)
                DateTime denNgayCuoiNgay = denNgay.Date.AddDays(1).AddTicks(-1);

                string query = @"
                    SELECT 
                        (SELECT COUNT(*) FROM PhieuDatPhong WHERE NgayLap >= @TuNgay AND NgayLap <= @DenNgay) AS SoPhieuDat,
                        (SELECT COUNT(*) FROM PhieuDatPhong WHERE TrangThai = N'Đang ở') AS DangO,
                        (SELECT COUNT(*) FROM HoaDon WHERE NgayLap >= @TuNgay AND NgayLap <= @DenNgay AND TrangThai = N'Đã thanh toán') AS SoHoaDon,
                        (SELECT ISNULL(SUM(TongTien), 0) FROM HoaDon WHERE NgayLap >= @TuNgay AND NgayLap <= @DenNgay AND TrangThai = N'Đã thanh toán') AS DoanhThuHD,
                        (SELECT ISNULL(SUM(TongTien), 0) FROM PhieuDenBu WHERE NgayLap >= @TuNgay AND NgayLap <= @DenNgay) AS TongDenBu";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TuNgay", tuNgay.Date);
                    cmd.Parameters.AddWithValue("@DenNgay", denNgayCuoiNgay);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Lấy danh sách thống kê dịch vụ đã sử dụng trong khoảng thời gian
        /// </summary>
        public DataTable LayThongKeDichVu(DateTime tuNgay, DateTime denNgay)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"
                    SELECT 
                        dv.MaDV AS [Mã DV],
                        dv.TenDV AS [Tên dịch vụ],
                        ISNULL(SUM(ct.SoLuong), 0) AS [Tổng số lượng],
                        ISNULL(SUM(ct.ThanhTien), 0) AS [Tổng tiền]
                    FROM PhieuSuDungDV p
                    INNER JOIN ChiTietPhieuSuDungDV ct ON p.SoPhieuSDDV = ct.SoPhieuSDDV
                    INNER JOIN DichVu dv ON ct.MaDV = dv.MaDV
                    WHERE p.NgaySuDung >= @TuNgay AND p.NgaySuDung <= @DenNgay
                    GROUP BY dv.MaDV, dv.TenDV";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TuNgay", tuNgay.Date);
                    cmd.Parameters.AddWithValue("@DenNgay", denNgay.Date);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }
    }
}