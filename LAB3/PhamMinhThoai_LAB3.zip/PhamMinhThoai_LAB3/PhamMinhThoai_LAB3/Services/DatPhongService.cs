﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyKhachSan.Services
{
    public class DatPhongService
    {
        // ⚠️ Thay đổi Data Source cho khớp với tên Server trên máy bạn (ví dụ: .\SQLEXPRESS hoặc .)
        private readonly string _connectionString = @"Data Source=PHAMMINHTHOAI\THOAI;Initial Catalog=QuanLyKhachSan;Integrated Security=True;TrustServerCertificate=True";

        /// <summary>
        /// Lấy danh sách các phòng có trạng thái 'Trống' để hiển thị ở bảng bên trái
        /// </summary>
        public DataTable LayDanhSachPhongTrong()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"SELECT 
                                    p.SoPhong AS [Phong], 
                                    k.TenKhuVuc AS [Khu], 
                                    p.SoNguoiToiDa AS [SucChua], 
                                    p.DonGiaNgay AS [DonGia]
                                FROM Phong p
                                INNER JOIN KhuVuc k ON p.MaKhuVuc = k.MaKhuVuc
                                WHERE p.TrangThai = N'Trống'";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Lấy danh sách phiếu đặt phòng hiển thị ở bảng phía dưới
        /// </summary>
        public DataTable LayDanhSachPhieuDat()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"SELECT 
                                    p.SoPhieuDat AS [SoPhieu], 
                                    k.HoTen AS [Khach], 
                                    p.NgayNhan, 
                                    p.NgayTraDuKien, 
                                    p.TienCoc AS [Coc], 
                                    p.KenhDat AS [Kenh], 
                                    p.TrangThai
                                FROM PhieuDatPhong p
                                INNER JOIN KhachHang k ON p.MaKhach = k.MaKhach";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Thực hiện lưu phiếu đặt phòng, chi tiết đặt phòng và cập nhật trạng thái phòng
        /// </summary>
        public bool TaoPhieuDatPhong(string soPhieu, string maKhach, string kenhDat, decimal tienCoc, DataTable dtPhongChon)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // 1. Tự động thêm Khách hàng nếu mã khách chưa tồn tại (tránh lỗi khóa ngoại FK)
                    string checkKhach = "SELECT COUNT(*) FROM KhachHang WHERE MaKhach = @MaKhach";
                    using (SqlCommand cmdCheck = new SqlCommand(checkKhach, conn, transaction))
                    {
                        cmdCheck.Parameters.AddWithValue("@MaKhach", maKhach);
                        int count = (int)cmdCheck.ExecuteScalar();
                        if (count == 0)
                        {
                            string insertKhach = "INSERT INTO KhachHang (MaKhach, HoTen, SoCMND, QuocTich) VALUES (@MaKhach, @HoTen, @SoCMND, @QuocTich)";
                            using (SqlCommand cmdInsKhach = new SqlCommand(insertKhach, conn, transaction))
                            {
                                cmdInsKhach.Parameters.AddWithValue("@MaKhach", maKhach);
                                cmdInsKhach.Parameters.AddWithValue("@HoTen", maKhach);
                                cmdInsKhach.Parameters.AddWithValue("@SoCMND", "CMND_" + maKhach);
                                cmdInsKhach.Parameters.AddWithValue("@QuocTich", "Việt Nam");
                                cmdInsKhach.ExecuteNonQuery();
                            }
                        }
                    }

                    // 2. Thêm vào bảng PhieuDatPhong
                    string insertPhieu = @"INSERT INTO PhieuDatPhong 
                        (SoPhieuDat, MaKhach, MaNVLeTan, NgayLap, NgayNhan, NgayTraDuKien, TienCoc, KenhDat, TrangThai)
                        VALUES 
                        (@SoPhieuDat, @MaKhach, 'NV01', GETDATE(), GETDATE(), DATEADD(day, 1, GETDATE()), @TienCoc, @KenhDat, N'Đã đặt')";

                    using (SqlCommand cmdPhieu = new SqlCommand(insertPhieu, conn, transaction))
                    {
                        cmdPhieu.Parameters.AddWithValue("@SoPhieuDat", soPhieu);
                        cmdPhieu.Parameters.AddWithValue("@MaKhach", maKhach);
                        cmdPhieu.Parameters.AddWithValue("@TienCoc", tienCoc);
                        cmdPhieu.Parameters.AddWithValue("@KenhDat", string.IsNullOrEmpty(kenhDat) ? "Website" : kenhDat);
                        cmdPhieu.ExecuteNonQuery();
                    }

                    // 3. Lặp qua các phòng chọn: Thêm ChiTietDatPhong & Đổi trạng thái Phong -> 'Đã đặt'
                    foreach (DataRow row in dtPhongChon.Rows)
                    {
                        string soPhong = row["PhongChon"].ToString();
                        int soNguoi = Convert.ToInt32(row["SoNguoi"]);

                        string insertCT = "INSERT INTO ChiTietDatPhong (SoPhieuDat, SoPhong, SoNguoi) VALUES (@SoPhieu, @SoPhong, @SoNguoi)";
                        using (SqlCommand cmdCT = new SqlCommand(insertCT, conn, transaction))
                        {
                            cmdCT.Parameters.AddWithValue("@SoPhieu", soPhieu);
                            cmdCT.Parameters.AddWithValue("@SoPhong", soPhong);
                            cmdCT.Parameters.AddWithValue("@SoNguoi", soNguoi);
                            cmdCT.ExecuteNonQuery();
                        }

                        string updatePhong = "UPDATE Phong SET TrangThai = N'Đã đặt' WHERE SoPhong = @SoPhong";
                        using (SqlCommand cmdUpdate = new SqlCommand(updatePhong, conn, transaction))
                        {
                            cmdUpdate.Parameters.AddWithValue("@SoPhong", soPhong);
                            cmdUpdate.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                    return true;
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
    }
}