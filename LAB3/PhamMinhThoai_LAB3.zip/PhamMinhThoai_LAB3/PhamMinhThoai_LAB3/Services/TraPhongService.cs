﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyKhachSan.Services
{
    public class TraPhongService
    {
        // Chuỗi kết nối đến CSDL của bạn
        private readonly string _connectionString = @"Data Source=PHAMMINHTHOAI\THOAI;Initial Catalog=QuanLyKhachSan;Integrated Security=True;TrustServerCertificate=True";

        /// <summary>
        /// Lấy thông tin phòng và đơn giá theo phiếu đặt
        /// </summary>
        public DataTable LayThongTinPhong(string soPhieuDat)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                // Cột trong bảng Phong là DonGiaNgay
                string query = @"SELECT 
                                    p.SoPhong AS [Phong], 
                                    p.DonGiaNgay AS [DonGia/ngay]
                                FROM ChiTietDatPhong ct
                                INNER JOIN Phong p ON ct.SoPhong = p.SoPhong
                                WHERE ct.SoPhieuDat = @SoPhieuDat";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Lấy tiện nghi đang lắp đặt trong phòng theo phiếu đặt
        /// </summary>
        public DataTable LayTienNghiPhong(string soPhieuDat)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                // Liên kết qua PhieuLapDat, TienNghi và LoaiTienNghi
                string query = @"SELECT 
                                    tn.MaTienNghi AS [TienNghi], 
                                    ltn.TenLoaiTN AS [Loai], 
                                    pld.TinhTrang AS [TinhTrang]
                                FROM ChiTietDatPhong ct
                                INNER JOIN PhieuLapDat pld ON ct.SoPhong = pld.SoPhong
                                INNER JOIN TienNghi tn ON pld.MaTienNghi = tn.MaTienNghi
                                INNER JOIN LoaiTienNghi ltn ON tn.MaLoaiTN = ltn.MaLoaiTN
                                WHERE ct.SoPhieuDat = @SoPhieuDat";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Lấy danh sách tiện nghi đền bù theo phiếu đặt
        /// </summary>
        public DataTable LayTienNghiDenBu(string soPhieuDat)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"SELECT 
                                    tn.MaTienNghi AS [TienNghiDenBu], 
                                    ct.MucDoThietHai AS [MucDo], 
                                    ct.SoTien AS [SoTien]
                                FROM ChiTietPhieuDenBu ct
                                INNER JOIN PhieuDenBu pdb ON ct.SoPhieuDenBu = pdb.SoPhieuDenBu
                                INNER JOIN TienNghi tn ON ct.MaTienNghi = tn.MaTienNghi
                                WHERE pdb.SoPhieuDat = @SoPhieuDat";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Lập phiếu đền bù
        /// </summary>
        public bool LapPhieuDenBu(string soPhieuDenBu, string soPhieuDat, string mucDo, decimal soTien)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                // Lấy phòng đầu tiên trong phiếu đặt làm SoPhong mặc định cho PhieuDenBu
                string query = @"
                    DECLARE @SoPhong varchar(20);
                    SELECT TOP 1 @SoPhong = SoPhong FROM ChiTietDatPhong WHERE SoPhieuDat = @SoPhieuDat;

                    INSERT INTO PhieuDenBu (SoPhieuDenBu, SoPhieuDat, SoPhong, NgayLap, MaNV, TongTien) 
                    VALUES (@SoPhieuDenBu, @SoPhieuDat, @SoPhong, GETDATE(), 'NV01', @SoTien)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoPhieuDenBu", soPhieuDenBu);
                    cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                    cmd.Parameters.AddWithValue("@SoTien", soTien);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        /// <summary>
        /// Lập hóa đơn thanh toán (Tính Tiền Phòng + Tiền Dịch Vụ)
        /// </summary>
        public bool LapHoaDon(string soHoaDon, string soPhieuDat, int soNgayTinhTien)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                // Tự động tính TienPhong và TienDichVu dựa trên dữ liệu thực tế trong CSDL
                string query = @"
                    DECLARE @TienPhong decimal(18,2);
                    DECLARE @TienDichVu decimal(18,2);

                    SELECT @TienPhong = ISNULL(SUM(p.DonGiaNgay), 0) * @SoNgay
                    FROM ChiTietDatPhong ct
                    INNER JOIN Phong p ON ct.SoPhong = p.SoPhong
                    WHERE ct.SoPhieuDat = @SoPhieuDat;

                    SELECT @TienDichVu = ISNULL(SUM(ctdv.ThanhTien), 0)
                    FROM PhieuSuDungDV pdv
                    INNER JOIN ChiTietPhieuSuDungDV ctdv ON pdv.SoPhieuSDDV = ctdv.SoPhieuSDDV
                    WHERE pdv.SoPhieuDat = @SoPhieuDat;

                    INSERT INTO HoaDon (SoHoaDon, SoPhieuDat, NgayLap, MaNV, SoNgayTinhTien, TienPhong, TienDichVu, TrangThai)
                    VALUES (@SoHoaDon, @SoPhieuDat, GETDATE(), 'NV01', @SoNgay, @TienPhong, @TienDichVu, N'Chưa thanh toán')";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoHoaDon", soHoaDon);
                    cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                    cmd.Parameters.AddWithValue("@SoNgay", soNgayTinhTien);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        /// <summary>
        /// Lấy danh sách hóa đơn theo phiếu đặt
        /// </summary>
        public DataTable LayDanhSachHoaDon(string soPhieuDat)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"SELECT 
                                    hd.SoHoaDon AS [HoaDon],
                                    hd.SoPhieuDat AS [PhieuDat],
                                    hd.TienPhong AS [TienPhong],
                                    hd.TienDichVu AS [TienDichVu],
                                    hd.TongTien AS [TongTien],
                                    hd.TrangThai AS [TrangThai]
                                FROM HoaDon hd
                                WHERE hd.SoPhieuDat = @SoPhieuDat";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Thực hiện thanh toán và ghi vào bảng ThanhToan
        /// </summary>
        public bool ThanhToan(string soPhieuDat, string hinhThuc, decimal soTien)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                // Chuẩn hóa Hình thức thanh toán khớp Ràng buộc CK_ThanhToan_HinhThuc (N'Tiền mặt', N'Chuyển khoản', N'Thẻ', N'Ví điện tử')
                if (hinhThuc != "Tiền mặt" && hinhThuc != "Chuyển khoản" && hinhThuc != "Thẻ" && hinhThuc != "Ví điện tử")
                {
                    hinhThuc = "Thẻ";
                }

                string query = @"
                    DECLARE @SoHoaDon varchar(30);
                    SELECT TOP 1 @SoHoaDon = SoHoaDon FROM HoaDon WHERE SoPhieuDat = @SoPhieuDat;

                    IF @SoHoaDon IS NOT NULL
                    BEGIN
                        -- Thêm bản ghi vào bảng ThanhToan
                        INSERT INTO ThanhToan (MaThanhToan, SoHoaDon, NgayThanhToan, HinhThuc, SoTien)
                        VALUES ('TT' + CONVERT(varchar(12), GETDATE(), 112) + RIGHT('0000' + CAST(ABS(CHECKSUM(NEWID())) % 10000 AS varchar(4)), 4), @SoHoaDon, GETDATE(), @HinhThuc, @SoTien);

                        -- Cập nhật trạng thái Hóa đơn
                        UPDATE HoaDon 
                        SET TrangThai = N'Đã thanh toán' 
                        WHERE SoHoaDon = @SoHoaDon;
                    END";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@HinhThuc", hinhThuc);
                    cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                    cmd.Parameters.AddWithValue("@SoTien", soTien);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        /// <summary>
        /// Hoàn tất trả phòng: Cập nhật trạng thái phiếu đặt và chuyển phòng về 'Trống'
        /// </summary>
        public bool HoanTatTraPhong(string soPhieuDat)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                // Sửa TrangThai thành N'Đã trả' để thỏa mãn CK_PhieuDat_TrangThai
                string query = @"
                    UPDATE PhieuDatPhong 
                    SET TrangThai = N'Đã trả', NgayTraThucTe = GETDATE() 
                    WHERE SoPhieuDat = @SoPhieuDat;

                    UPDATE Phong 
                    SET TrangThai = N'Trống' 
                    WHERE SoPhong IN (SELECT SoPhong FROM ChiTietDatPhong WHERE SoPhieuDat = @SoPhieuDat);";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}