﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyKhachSan.Services
{
    public class DichVuService
    {
        // ⚠️ Đổi Data Source phù hợp với Server SQL máy bạn (ví dụ: .\SQLEXPRESS hoặc .)
        private readonly string _connectionString = @"Data Source=PHAMMINHTHOAI\THOAI;Initial Catalog=QuanLyKhachSan;Integrated Security=True;TrustServerCertificate=True";

        /// <summary>
        /// Lấy danh sách phiếu sử dụng dịch vụ hiển thị lên DataGridView
        /// </summary>
        public DataTable LayDanhSachSuDungDichVu()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = @"SELECT 
                                    p.SoPhieuDat AS [SoPhieu],
                                    p.SoPhong AS [Phong],
                                    p.NgaySuDung AS [Ngay],
                                    d.TenDV AS [DichVu],
                                    c.SoLuong AS [SoLuong],
                                    c.DonGia AS [DonGia],
                                    c.ThanhTien AS [ThanhTien]
                                FROM PhieuSuDungDV p
                                INNER JOIN ChiTietPhieuSuDungDV c ON p.SoPhieuSDDV = c.SoPhieuSDDV
                                INNER JOIN DichVu d ON c.MaDV = d.MaDV
                                ORDER BY p.NgaySuDung DESC";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Ghi nhận dịch vụ khách hàng sử dụng
        /// </summary>
        public bool GhiNhanSuDungDV(string soPhieuDat, string soPhong, string tenDichVu, DateTime ngaySuDung, int soLuong)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // 1. Kiểm tra Dịch vụ có tồn tại không (tìm theo tên hoặc mã)
                    string queryDV = "SELECT MaDV, DonGia FROM DichVu WHERE TenDV = @TenDV OR MaDV = @TenDV";
                    string maDV = "";
                    decimal donGia = 0;

                    using (SqlCommand cmdDV = new SqlCommand(queryDV, conn, transaction))
                    {
                        cmdDV.Parameters.AddWithValue("@TenDV", tenDichVu);
                        using (SqlDataReader reader = cmdDV.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                maDV = reader["MaDV"].ToString();
                                donGia = Convert.ToDecimal(reader["DonGia"]);
                            }
                            else
                            {
                                throw new Exception("Không tìm thấy dịch vụ '" + tenDichVu + "' trong CSDL!");
                            }
                        }
                    }

                    // 2. Kiểm tra/Tạo ChiTietDatPhong nếu chưa có (tránh lỗi khóa ngoại FK)
                    string queryCTDat = "SELECT COUNT(*) FROM ChiTietDatPhong WHERE SoPhieuDat = @SoPhieuDat AND SoPhong = @SoPhong";
                    using (SqlCommand cmdCT = new SqlCommand(queryCTDat, conn, transaction))
                    {
                        cmdCT.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                        cmdCT.Parameters.AddWithValue("@SoPhong", soPhong);
                        int count = (int)cmdCT.ExecuteScalar();
                        if (count == 0)
                        {
                            // Tự động tạo ChiTietDatPhong giả định để không bị chặn bởi Constraint FK
                            string insCTDat = "INSERT INTO ChiTietDatPhong (SoPhieuDat, SoPhong, SoNguoi) VALUES (@SoPhieuDat, @SoPhong, 1)";
                            using (SqlCommand cmdInsCT = new SqlCommand(insCTDat, conn, transaction))
                            {
                                cmdInsCT.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                                cmdInsCT.Parameters.AddWithValue("@SoPhong", soPhong);
                                cmdInsCT.ExecuteNonQuery();
                            }
                        }
                    }

                    // 3. Kiểm tra xem PhieuSuDungDV đã tồn tại theo (SoPhieuDat, SoPhong, NgaySuDung) chưa
                    string queryPhieuSD = "SELECT SoPhieuSDDV FROM PhieuSuDungDV WHERE SoPhieuDat = @SoPhieuDat AND SoPhong = @SoPhong AND NgaySuDung = @NgaySuDung";
                    string soPhieuSDDV = "";

                    using (SqlCommand cmdPhieu = new SqlCommand(queryPhieuSD, conn, transaction))
                    {
                        cmdPhieu.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                        cmdPhieu.Parameters.AddWithValue("@SoPhong", soPhong);
                        cmdPhieu.Parameters.AddWithValue("@NgaySuDung", ngaySuDung.Date);

                        object result = cmdPhieu.ExecuteScalar();
                        if (result != null)
                        {
                            soPhieuSDDV = result.ToString();
                        }
                    }

                    // Nếu chưa có phiếu sử dụng dịch vụ cho ngày này -> Tạo mới
                    if (string.IsNullOrEmpty(soPhieuSDDV))
                    {
                        soPhieuSDDV = "SDDV_" + DateTime.Now.ToString("yyyyMMddHHmmss");
                        string insPhieuSD = @"INSERT INTO PhieuSuDungDV (SoPhieuSDDV, SoPhieuDat, SoPhong, NgaySuDung, MaNV) 
                                              VALUES (@SoPhieuSDDV, @SoPhieuDat, @SoPhong, @NgaySuDung, 'NV01')";

                        using (SqlCommand cmdInsPhieu = new SqlCommand(insPhieuSD, conn, transaction))
                        {
                            cmdInsPhieu.Parameters.AddWithValue("@SoPhieuSDDV", soPhieuSDDV);
                            cmdInsPhieu.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                            cmdInsPhieu.Parameters.AddWithValue("@SoPhong", soPhong);
                            cmdInsPhieu.Parameters.AddWithValue("@NgaySuDung", ngaySuDung.Date);
                            cmdInsPhieu.ExecuteNonQuery();
                        }
                    }

                    // 4. Thêm hoặc Cập nhật ChiTietPhieuSuDungDV
                    string queryCheckCT = "SELECT COUNT(*) FROM ChiTietPhieuSuDungDV WHERE SoPhieuSDDV = @SoPhieuSDDV AND MaDV = @MaDV";
                    using (SqlCommand cmdCheckCT = new SqlCommand(queryCheckCT, conn, transaction))
                    {
                        cmdCheckCT.Parameters.AddWithValue("@SoPhieuSDDV", soPhieuSDDV);
                        cmdCheckCT.Parameters.AddWithValue("@MaDV", maDV);
                        int existCT = (int)cmdCheckCT.ExecuteScalar();

                        if (existCT > 0)
                        {
                            string updateCT = "UPDATE ChiTietPhieuSuDungDV SET SoLuong = SoLuong + @SoLuong WHERE SoPhieuSDDV = @SoPhieuSDDV AND MaDV = @MaDV";
                            using (SqlCommand cmdUp = new SqlCommand(updateCT, conn, transaction))
                            {
                                cmdUp.Parameters.AddWithValue("@SoLuong", soLuong);
                                cmdUp.Parameters.AddWithValue("@SoPhieuSDDV", soPhieuSDDV);
                                cmdUp.Parameters.AddWithValue("@MaDV", maDV);
                                cmdUp.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            string insertCT = "INSERT INTO ChiTietPhieuSuDungDV (SoPhieuSDDV, MaDV, SoLuong, DonGia) VALUES (@SoPhieuSDDV, @MaDV, @SoLuong, @DonGia)";
                            using (SqlCommand cmdIns = new SqlCommand(insertCT, conn, transaction))
                            {
                                cmdIns.Parameters.AddWithValue("@SoPhieuSDDV", soPhieuSDDV);
                                cmdIns.Parameters.AddWithValue("@MaDV", maDV);
                                cmdIns.Parameters.AddWithValue("@SoLuong", soLuong);
                                cmdIns.Parameters.AddWithValue("@DonGia", donGia);
                                cmdIns.ExecuteNonQuery();
                            }
                        }
                    }

                    transaction.Commit();
                    return true;
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
    }
}