﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Services
{
    public class DanhMucService
    {
        // ==================== 1. QUẢN LÝ KHU VỰC ====================
        public DataTable LayKhuVuc()
        {
            string sql = "SELECT MaKhuVuc, TenKhuVuc FROM KhuVuc ORDER BY MaKhuVuc";
            return Db.ExecuteQuery(sql);
        }

        public bool ThemKhuVuc(string ma, string ten)
        {
            string sql = "INSERT INTO KhuVuc(MaKhuVuc, TenKhuVuc) VALUES(@Ma, @Ten)";
            SqlParameter[] p = {
                new SqlParameter("@Ma", ma),
                new SqlParameter("@Ten", ten)
            };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        public bool SuaKhuVuc(string ma, string ten)
        {
            string sql = "UPDATE KhuVuc SET TenKhuVuc = @Ten WHERE MaKhuVuc = @Ma";
            SqlParameter[] p = {
                new SqlParameter("@Ma", ma),
                new SqlParameter("@Ten", ten)
            };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        public bool XoaKhuVuc(string ma)
        {
            string sql = "DELETE FROM KhuVuc WHERE MaKhuVuc = @Ma";
            SqlParameter[] p = { new SqlParameter("@Ma", ma) };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        // ==================== 2. QUẢN LÝ DỊCH VỤ ====================
        public DataTable LayDichVu()
        {
            string sql = "SELECT MaDV, TenDV, DonViTinh, DonGia FROM DichVu ORDER BY MaDV";
            return Db.ExecuteQuery(sql);
        }

        public bool ThemDichVu(string ma, string ten, decimal donGia, string donViTinh)
        {
            string sql = "INSERT INTO DichVu(MaDV, TenDV, DonViTinh, DonGia) VALUES(@Ma, @Ten, @DVT, @DonGia)";
            SqlParameter[] p = {
                new SqlParameter("@Ma", ma),
                new SqlParameter("@Ten", ten),
                new SqlParameter("@DVT", donViTinh),
                new SqlParameter("@DonGia", donGia)
            };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        public bool SuaDichVu(string ma, string ten, decimal donGia, string donViTinh)
        {
            string sql = "UPDATE DichVu SET TenDV = @Ten, DonViTinh = @DVT, DonGia = @DonGia WHERE MaDV = @Ma";
            SqlParameter[] p = {
                new SqlParameter("@Ma", ma),
                new SqlParameter("@Ten", ten),
                new SqlParameter("@DVT", donViTinh),
                new SqlParameter("@DonGia", donGia)
            };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        public bool XoaDichVu(string ma)
        {
            string sql = "DELETE FROM DichVu WHERE MaDV = @Ma";
            SqlParameter[] p = { new SqlParameter("@Ma", ma) };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        // ==================== 3. QUẢN LÝ NHÂN VIÊN ====================
        public DataTable LayNhanVien()
        {
            string sql = "SELECT MaNV, HoTen, VaiTro, SoDienThoai FROM NhanVien ORDER BY MaNV";
            return Db.ExecuteQuery(sql);
        }

        public bool ThemNhanVien(string ma, string hoTen, string vaiTro, string sdt)
        {
            string sql = "INSERT INTO NhanVien(MaNV, HoTen, VaiTro, SoDienThoai) VALUES(@Ma, @HoTen, @VaiTro, @SDT)";
            SqlParameter[] p = {
                new SqlParameter("@Ma", ma),
                new SqlParameter("@HoTen", hoTen),
                new SqlParameter("@VaiTro", vaiTro),
                new SqlParameter("@SDT", string.IsNullOrEmpty(sdt) ? (object)DBNull.Value : sdt)
            };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        public bool SuaNhanVien(string ma, string hoTen, string vaiTro, string sdt)
        {
            string sql = "UPDATE NhanVien SET HoTen = @HoTen, VaiTro = @VaiTro, SoDienThoai = @SDT WHERE MaNV = @Ma";
            SqlParameter[] p = {
                new SqlParameter("@Ma", ma),
                new SqlParameter("@HoTen", hoTen),
                new SqlParameter("@VaiTro", vaiTro),
                new SqlParameter("@SDT", string.IsNullOrEmpty(sdt) ? (object)DBNull.Value : sdt)
            };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        public bool XoaNhanVien(string ma)
        {
            string sql = "DELETE FROM NhanVien WHERE MaNV = @Ma";
            SqlParameter[] p = { new SqlParameter("@Ma", ma) };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        // ==================== 4. QUẢN LÝ LOẠI TIỆN NGHĨ ====================
        public DataTable LayLoaiTienNghi()
        {
            string sql = "SELECT MaLoaiTN, TenLoaiTN FROM LoaiTienNghi ORDER BY MaLoaiTN";
            return Db.ExecuteQuery(sql);
        }

        public bool ThemLoaiTienNghi(string ma, string ten)
        {
            string sql = "INSERT INTO LoaiTienNghi(MaLoaiTN, TenLoaiTN) VALUES(@Ma, @Ten)";
            SqlParameter[] p = {
                new SqlParameter("@Ma", ma),
                new SqlParameter("@Ten", ten)
            };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }

        // ==================== 5. QUẢN LÝ QUY ĐỊNH ĐỀN BÙ ====================
        public DataTable LayQuyDinhDenBu()
        {
            string sql = @"SELECT q.MaQuyDinh, l.TenLoaiTN, q.MucDoThietHai, q.MucDenBu 
                           FROM QuyDinhDenBu q 
                           JOIN LoaiTienNghi l ON q.MaLoaiTN = l.MaLoaiTN";
            return Db.ExecuteQuery(sql);
        }

        public bool ThemQuyDinhDenBu(string ma, string maLoaiTN, string mucDo, decimal mucDenBu)
        {
            string sql = "INSERT INTO QuyDinhDenBu(MaQuyDinh, MaLoaiTN, MucDoThietHai, MucDenBu) VALUES(@Ma, @MaLoai, @MucDo, @MucDenBu)";
            SqlParameter[] p = {
                new SqlParameter("@Ma", ma),
                new SqlParameter("@MaLoai", maLoaiTN),
                new SqlParameter("@MucDo", mucDo),
                new SqlParameter("@MucDenBu", mucDenBu)
            };
            return Db.ExecuteNonQuery(sql, p) > 0;
        }
    }
}