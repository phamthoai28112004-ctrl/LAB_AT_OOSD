﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmDatPhong : Form
    {
        private readonly DatPhongService _service = new DatPhongService();
        private DataTable _dtPhongChon;

        public FrmDatPhong()
        {
            InitializeComponent();
        }

        private void FrmDatPhong_Load(object sender, EventArgs e)
        {
            KhoiTaoBangPhongChon();
            TaiDanhSachPhongTrong();
            TaiDanhSachPhieuDat();
        }

        // Khởi tạo bảng danh sách phòng chọn (Grid phía trên bên phải)
        private void KhoiTaoBangPhongChon()
        {
            _dtPhongChon = new DataTable();
            _dtPhongChon.Columns.Add("PhongChon", typeof(string));
            _dtPhongChon.Columns.Add("SoNguoi", typeof(int));
            _dtPhongChon.Columns.Add("DonGiaNgay", typeof(decimal));

            dgvPhongChon.DataSource = _dtPhongChon;

            if (dgvPhongChon.Columns["PhongChon"] != null) dgvPhongChon.Columns["PhongChon"].HeaderText = "Phòng chọn";
            if (dgvPhongChon.Columns["SoNguoi"] != null) dgvPhongChon.Columns["SoNguoi"].HeaderText = "Số người";
            if (dgvPhongChon.Columns["DonGiaNgay"] != null) dgvPhongChon.Columns["DonGiaNgay"].HeaderText = "Đơn giá/ngày";
        }

        // Tải bảng danh sách phòng trống (Grid phía trên bên trái)
        private void TaiDanhSachPhongTrong()
        {
            try
            {
                DataTable dt = _service.LayDanhSachPhongTrong();
                dgvPhongTrong.DataSource = dt;

                if (dgvPhongTrong.Columns["Phong"] != null) dgvPhongTrong.Columns["Phong"].HeaderText = "Phòng";
                if (dgvPhongTrong.Columns["Khu"] != null) dgvPhongTrong.Columns["Khu"].HeaderText = "Khu";
                if (dgvPhongTrong.Columns["SucChua"] != null) dgvPhongTrong.Columns["SucChua"].HeaderText = "Sức chứa";
                if (dgvPhongTrong.Columns["DonGia"] != null) dgvPhongTrong.Columns["DonGia"].HeaderText = "Đơn giá";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách phòng trống: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Tải danh sách phiếu đặt (Grid bên dưới)
        private void TaiDanhSachPhieuDat()
        {
            try
            {
                DataTable dt = _service.LayDanhSachPhieuDat();
                dgvPhieuDatPhong.DataSource = dt;

                if (dgvPhieuDatPhong.Columns["SoPhieu"] != null) dgvPhieuDatPhong.Columns["SoPhieu"].HeaderText = "Số phiếu";
                if (dgvPhieuDatPhong.Columns["Khach"] != null) dgvPhieuDatPhong.Columns["Khach"].HeaderText = "Khách";
                if (dgvPhieuDatPhong.Columns["NgayNhan"] != null) dgvPhieuDatPhong.Columns["NgayNhan"].HeaderText = "Ngày nhận";
                if (dgvPhieuDatPhong.Columns["NgayTraDuKien"] != null) dgvPhieuDatPhong.Columns["NgayTraDuKien"].HeaderText = "Ngày trả dự kiến";
                if (dgvPhieuDatPhong.Columns["Coc"] != null) dgvPhieuDatPhong.Columns["Coc"].HeaderText = "Cọc";
                if (dgvPhieuDatPhong.Columns["Kenh"] != null) dgvPhieuDatPhong.Columns["Kenh"].HeaderText = "Kênh";
                if (dgvPhieuDatPhong.Columns["TrangThai"] != null) dgvPhieuDatPhong.Columns["TrangThai"].HeaderText = "Trạng thái";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách phiếu đặt: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Sự kiện Đúp chuột vào dòng phòng trống -> Tự động chuyển phòng đó sang bảng "Phòng chọn"
        private void dgvPhongTrong_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvPhongTrong.Rows[e.RowIndex];
                string soPhong = row.Cells["Phong"].Value?.ToString();
                int sucChua = Convert.ToInt32(row.Cells["SucChua"].Value ?? 1);
                decimal donGia = Convert.ToDecimal(row.Cells["DonGia"].Value ?? 0);

                // Kiểm tra xem phòng đã được chọn trước đó chưa
                foreach (DataRow r in _dtPhongChon.Rows)
                {
                    if (r["PhongChon"].ToString() == soPhong)
                    {
                        MessageBox.Show("Phòng này đã nằm trong danh sách chọn!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // Thêm vào bảng chọn
                _dtPhongChon.Rows.Add(soPhong, sucChua, donGia);
            }
        }

        // Sự kiện Click nút "Lập phiếu đặt"
        private void btnLapPhieuDat_Click(object sender, EventArgs e)
        {
            string soPhieu = txtSoPhieuDat.Text.Trim();
            string khach = txtKhach.Text.Trim();
            string kenhDat = txtKenhDat.Text.Trim();
            string strTienCoc = txtTienCoc.Text.Trim();

            if (string.IsNullOrEmpty(soPhieu) || string.IsNullOrEmpty(khach))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Số phiếu đặt và Khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_dtPhongChon.Rows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn ít nhất 1 phòng (Đúp chuột vào phòng trống ở bảng bên trái)!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal tienCoc = 0;
            decimal.TryParse(strTienCoc, out tienCoc);

            try
            {
                if (_service.TaoPhieuDatPhong(soPhieu, khach, kenhDat, tienCoc, _dtPhongChon))
                {
                    MessageBox.Show("Lập phiếu đặt phòng thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Xóa dữ liệu cũ trên Form & làm mới DataGridView
                    _dtPhongChon.Clear();
                    txtSoPhieuDat.Clear();
                    txtKhach.Clear();
                    txtKenhDat.Clear();
                    txtTienCoc.Clear();

                    TaiDanhSachPhongTrong();
                    TaiDanhSachPhieuDat();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập phiếu đặt phòng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}