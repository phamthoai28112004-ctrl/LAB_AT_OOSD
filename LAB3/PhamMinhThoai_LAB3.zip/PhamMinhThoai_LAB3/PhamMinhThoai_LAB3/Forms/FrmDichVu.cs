﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmDichVu : Form
    {
        private readonly DichVuService _service = new DichVuService();

        public FrmDichVu()
        {
            InitializeComponent();
        }

        private void FrmDichVu_Load(object sender, EventArgs e)
        {
            TaiDanhSachSuDungDV();
        }

        private void TaiDanhSachSuDungDV()
        {
            try
            {
                DataTable dt = _service.LayDanhSachSuDungDichVu();
                dgvSuDungDV.DataSource = dt;

                // Cấu hình tiêu đề cột hiển thị trên DataGridView
                if (dgvSuDungDV.Columns["SoPhieu"] != null) dgvSuDungDV.Columns["SoPhieu"].HeaderText = "Số phiếu";
                if (dgvSuDungDV.Columns["Phong"] != null) dgvSuDungDV.Columns["Phong"].HeaderText = "Phòng";
                if (dgvSuDungDV.Columns["Ngay"] != null) dgvSuDungDV.Columns["Ngay"].HeaderText = "Ngày";
                if (dgvSuDungDV.Columns["DichVu"] != null) dgvSuDungDV.Columns["DichVu"].HeaderText = "Dịch vụ";
                if (dgvSuDungDV.Columns["SoLuong"] != null) dgvSuDungDV.Columns["SoLuong"].HeaderText = "Số lượng";
                if (dgvSuDungDV.Columns["DonGia"] != null) dgvSuDungDV.Columns["DonGia"].HeaderText = "Đơn giá";
                if (dgvSuDungDV.Columns["ThanhTien"] != null) dgvSuDungDV.Columns["ThanhTien"].HeaderText = "Thành tiền";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách sử dụng dịch vụ: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnGhiNhan_Click(object sender, EventArgs e)
        {
            string phieuLuuTru = txtPhieuLuuTru.Text.Trim();
            string phong = txtPhong.Text.Trim();
            string dichVu = txtDichVu.Text.Trim();
            string strNgay = txtNgaySuDung.Text.Trim();
            string strSoLuong = txtSoLuong.Text.Trim();

            if (string.IsNullOrEmpty(phieuLuuTru) || string.IsNullOrEmpty(phong) || string.IsNullOrEmpty(dichVu))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Phiếu lưu trú, Phòng và Dịch vụ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DateTime ngaySuDung;
            if (!DateTime.TryParseExact(strNgay, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out ngaySuDung))
            {
                if (!DateTime.TryParse(strNgay, out ngaySuDung))
                {
                    ngaySuDung = DateTime.Now;
                }
            }

            int soLuong = 1;
            int.TryParse(strSoLuong, out soLuong);

            try
            {
                if (_service.GhiNhanSuDungDV(phieuLuuTru, phong, dichVu, ngaySuDung, soLuong))
                {
                    MessageBox.Show("Ghi nhận sử dụng dịch vụ thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    TaiDanhSachSuDungDV();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi ghi nhận dịch vụ: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}