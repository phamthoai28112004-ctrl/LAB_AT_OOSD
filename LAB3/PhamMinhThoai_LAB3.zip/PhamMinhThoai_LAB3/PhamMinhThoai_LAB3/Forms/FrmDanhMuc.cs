﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmDanhMuc : Form
    {
        private enum LoaiDanhMuc { KhuVuc, NhanVien, LoaiTienNghi, DichVu, QuyDinhDenBu }
        private LoaiDanhMuc _danhMucHienTai = LoaiDanhMuc.KhuVuc;
        private readonly DanhMucService _service = new DanhMucService();

        public FrmDanhMuc()
        {
            InitializeComponent();
        }

        private void FrmDanhMuc_Load(object sender, EventArgs e)
        {
            ChuyenDanhMuc(LoaiDanhMuc.DichVu); // Mặc định mở Dịch vụ giống như ảnh mẫu
        }

        private void NavButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn == btnNavKhuVuc) ChuyenDanhMuc(LoaiDanhMuc.KhuVuc);
            else if (btn == btnNavNhanVien) ChuyenDanhMuc(LoaiDanhMuc.NhanVien);
            else if (btn == btnNavLoaiTN) ChuyenDanhMuc(LoaiDanhMuc.LoaiTienNghi);
            else if (btn == btnNavDichVu) ChuyenDanhMuc(LoaiDanhMuc.DichVu);
            else if (btn == btnNavQuyDinh) ChuyenDanhMuc(LoaiDanhMuc.QuyDinhDenBu);
        }

        private void ChuyenDanhMuc(LoaiDanhMuc dm)
        {
            _danhMucHienTai = dm;
            ResetNavButtons();
            ClearInputs();

            switch (dm)
            {
                case LoaiDanhMuc.KhuVuc:
                    btnNavKhuVuc.Font = new Font(btnNavKhuVuc.Font, FontStyle.Bold);
                    lblMa.Text = "Mã KV:";
                    lblTen.Text = "Tên khu vực:";
                    SetInputVisibility(extra1Visible: false, extra2Visible: false);
                    break;

                case LoaiDanhMuc.NhanVien:
                    btnNavNhanVien.Font = new Font(btnNavNhanVien.Font, FontStyle.Bold);
                    lblMa.Text = "Mã NV:";
                    lblTen.Text = "Họ tên:";
                    lblExtra1.Text = "Vai trò:";
                    lblExtra2.Text = "SĐT:";
                    SetInputVisibility(extra1Visible: true, extra2Visible: true);
                    break;

                case LoaiDanhMuc.LoaiTienNghi:
                    btnNavLoaiTN.Font = new Font(btnNavLoaiTN.Font, FontStyle.Bold);
                    lblMa.Text = "Mã loại:";
                    lblTen.Text = "Tên loại TN:";
                    SetInputVisibility(extra1Visible: false, extra2Visible: false);
                    break;

                case LoaiDanhMuc.DichVu:
                    btnNavDichVu.Font = new Font(btnNavDichVu.Font, FontStyle.Bold);
                    lblMa.Text = "Mã:";
                    lblTen.Text = "Tên:";
                    lblExtra1.Text = "Đơn vị / Vai trò:";
                    lblExtra2.Text = "Đơn giá:";
                    SetInputVisibility(extra1Visible: true, extra2Visible: true);
                    break;

                case LoaiDanhMuc.QuyDinhDenBu:
                    btnNavQuyDinh.Font = new Font(btnNavQuyDinh.Font, FontStyle.Bold);
                    lblMa.Text = "Mã quy định:";
                    lblTen.Text = "Mã loại TN:";
                    lblExtra1.Text = "Mức độ thù hỏng:";
                    lblExtra2.Text = "Mức đền bù:";
                    SetInputVisibility(extra1Visible: true, extra2Visible: true);
                    break;
            }

            TaiDuLieu();
        }

        private void SetInputVisibility(bool extra1Visible, bool extra2Visible)
        {
            lblExtra1.Visible = txtExtra1.Visible = extra1Visible;
            lblExtra2.Visible = txtExtra2.Visible = extra2Visible;
        }

        private void ResetNavButtons()
        {
            Font regularFont = new Font("Segoe UI", 10F, FontStyle.Regular);
            btnNavKhuVuc.Font = regularFont;
            btnNavNhanVien.Font = regularFont;
            btnNavLoaiTN.Font = regularFont;
            btnNavDichVu.Font = regularFont;
            btnNavQuyDinh.Font = regularFont;
        }

        private void TaiDuLieu()
        {
            dgvDanhMuc.Rows.Clear();
            try
            {
                DataTable dt = null;
                switch (_danhMucHienTai)
                {
                    case LoaiDanhMuc.KhuVuc:
                        dt = _service.LayKhuVuc();
                        foreach (DataRow r in dt.Rows)
                            dgvDanhMuc.Rows.Add(r["MaKhuVuc"], r["TenKhuVuc"], "", "", "");
                        break;

                    case LoaiDanhMuc.NhanVien:
                        dt = _service.LayNhanVien();
                        foreach (DataRow r in dt.Rows)
                            dgvDanhMuc.Rows.Add(r["MaNV"], r["HoTen"], r["VaiTro"], r["SoDienThoai"], "");
                        break;

                    case LoaiDanhMuc.LoaiTienNghi:
                        dt = _service.LayLoaiTienNghi();
                        foreach (DataRow r in dt.Rows)
                            dgvDanhMuc.Rows.Add(r["MaLoaiTN"], r["TenLoaiTN"], "", "", "");
                        break;

                    case LoaiDanhMuc.DichVu:
                        dt = _service.LayDichVu();
                        foreach (DataRow r in dt.Rows)
                            dgvDanhMuc.Rows.Add(r["MaDV"], r["TenDV"], "", r["DonViTinh"], Convert.ToDecimal(r["DonGia"]).ToString("N0"));
                        break;

                    case LoaiDanhMuc.QuyDinhDenBu:
                        dt = _service.LayQuyDinhDenBu();
                        foreach (DataRow r in dt.Rows)
                            dgvDanhMuc.Rows.Add(r["MaQuyDinh"], r["TenLoaiTN"], r["MucDoThietHai"], "", Convert.ToDecimal(r["MucDenBu"]).ToString("N0"));
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMa.Text) || string.IsNullOrWhiteSpace(txtTen.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool ketQua = false;
            string ma = txtMa.Text.Trim();
            string ten = txtTen.Text.Trim();

            switch (_danhMucHienTai)
            {
                case LoaiDanhMuc.KhuVuc:
                    ketQua = _service.ThemKhuVuc(ma, ten);
                    break;

                case LoaiDanhMuc.NhanVien:
                    ketQua = _service.ThemNhanVien(ma, ten, txtExtra1.Text.Trim(), txtExtra2.Text.Trim());
                    break;

                case LoaiDanhMuc.LoaiTienNghi:
                    ketQua = _service.ThemLoaiTienNghi(ma, ten);
                    break;

                case LoaiDanhMuc.DichVu:
                    if (decimal.TryParse(txtExtra2.Text, out decimal donGia))
                        ketQua = _service.ThemDichVu(ma, ten, donGia, txtExtra1.Text.Trim());
                    else
                        MessageBox.Show("Đơn giá không hợp lệ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;

                case LoaiDanhMuc.QuyDinhDenBu:
                    if (decimal.TryParse(txtExtra2.Text, out decimal mucDenBu))
                        ketQua = _service.ThemQuyDinhDenBu(ma, ten, txtExtra1.Text.Trim(), mucDenBu);
                    else
                        MessageBox.Show("Mức đền bù không hợp lệ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }

            if (ketQua)
            {
                MessageBox.Show("Thêm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDuLieu();
                ClearInputs();
            }
            else
            {
                MessageBox.Show("Thêm thất bại. Vui lòng kiểm tra lại dữ liệu nhập!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvDanhMuc_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvDanhMuc.Rows[e.RowIndex];
                txtMa.Text = row.Cells["colMa"].Value?.ToString();
                txtTen.Text = row.Cells["colTen"].Value?.ToString();
                txtExtra1.Text = _danhMucHienTai == LoaiDanhMuc.DichVu ? row.Cells["colDonVi"].Value?.ToString() : row.Cells["colLoaiVaiTro"].Value?.ToString();
                txtExtra2.Text = row.Cells["colDonGiaMuc"].Value?.ToString();
            }
        }

        private void ClearInputs()
        {
            txtMa.Clear();
            txtTen.Clear();
            txtExtra1.Clear();
            txtExtra2.Clear();
            txtMa.Focus();
        }
    }
}