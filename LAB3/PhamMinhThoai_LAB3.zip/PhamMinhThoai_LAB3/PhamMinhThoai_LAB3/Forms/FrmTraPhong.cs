﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmTraPhong : Form
    {
        private readonly TraPhongService _service = new TraPhongService();

        public FrmTraPhong()
        {
            InitializeComponent();
        }

        private void FrmTraPhong_Load(object sender, EventArgs e)
        {
            TaiThongTinForm();
        }

        private void txtPhieuDangO_Leave(object sender, EventArgs e)
        {
            TaiThongTinForm();
        }

        private void TaiThongTinForm()
        {
            string soPhieu = txtPhieuDangO.Text.Trim();
            if (string.IsNullOrEmpty(soPhieu)) return;

            try
            {
                dgvPhong.DataSource = _service.LayThongTinPhong(soPhieu);
                dgvTienNghi.DataSource = _service.LayTienNghiPhong(soPhieu);
                dgvTienNghiDenBu.DataSource = _service.LayTienNghiDenBu(soPhieu);
                dgvHoaDon.DataSource = _service.LayDanhSachHoaDon(soPhieu);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLapPhieuDenBu_Click(object sender, EventArgs e)
        {
            string soPhieuDenBu = txtSoPhieuDenBu.Text.Trim();
            string soPhieuDat = txtPhieuDangO.Text.Trim();
            string mucDo = txtMucDo.Text.Trim();
            decimal soTien = 0;
            decimal.TryParse(txtSoTienDenBu.Text.Trim(), out soTien);

            if (string.IsNullOrEmpty(soPhieuDenBu) || string.IsNullOrEmpty(soPhieuDat))
            {
                MessageBox.Show("Vui lòng nhập số phiếu đền bù và mã phiếu lưu trú!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (_service.LapPhieuDenBu(soPhieuDenBu, soPhieuDat, mucDo, soTien))
                {
                    MessageBox.Show("Lập phiếu đền bù thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    TaiThongTinForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập phiếu đền bù: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            string soHoaDon = txtSoHoaDon.Text.Trim();
            string soPhieuDat = txtPhieuDangO.Text.Trim();
            int soNgay = 1;
            int.TryParse(txtSoNgayTinhTien.Text.Trim(), out soNgay);

            if (string.IsNullOrEmpty(soHoaDon) || string.IsNullOrEmpty(soPhieuDat))
            {
                MessageBox.Show("Vui lòng nhập số hóa đơn!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (_service.LapHoaDon(soHoaDon, soPhieuDat, soNgay))
                {
                    MessageBox.Show("Lập hóa đơn thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    TaiThongTinForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập hóa đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            string soPhieuDat = txtPhieuDangO.Text.Trim();
            string hinhThuc = txtHinhThuc.Text.Trim();
            decimal soTien = 0;
            decimal.TryParse(txtSoTienThanhToan.Text.Trim(), out soTien);

            try
            {
                if (_service.ThanhToan(soPhieuDat, hinhThuc, soTien))
                {
                    MessageBox.Show("Thanh toán thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    TaiThongTinForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thanh toán: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHoanTatTraPhong_Click(object sender, EventArgs e)
        {
            string soPhieuDat = txtPhieuDangO.Text.Trim();

            try
            {
                if (_service.HoanTatTraPhong(soPhieuDat))
                {
                    MessageBox.Show("Hoàn tất quá trình trả phòng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hoàn tất trả phòng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}