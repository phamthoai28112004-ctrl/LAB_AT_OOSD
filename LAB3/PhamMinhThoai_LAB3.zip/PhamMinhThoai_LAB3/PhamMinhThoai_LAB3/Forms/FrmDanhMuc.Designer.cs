﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlNav = new System.Windows.Forms.Panel();
            this.btnNavQuyDinh = new System.Windows.Forms.Button();
            this.btnNavDichVu = new System.Windows.Forms.Button();
            this.btnNavLoaiTN = new System.Windows.Forms.Button();
            this.btnNavNhanVien = new System.Windows.Forms.Button();
            this.btnNavKhuVuc = new System.Windows.Forms.Button();
            this.pnlInput = new System.Windows.Forms.Panel();
            this.btnThem = new System.Windows.Forms.Button();
            this.txtExtra2 = new System.Windows.Forms.TextBox();
            this.lblExtra2 = new System.Windows.Forms.Label();
            this.txtExtra1 = new System.Windows.Forms.TextBox();
            this.lblExtra1 = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.lblTen = new System.Windows.Forms.Label();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.lblMa = new System.Windows.Forms.Label();
            this.dgvDanhMuc = new System.Windows.Forms.DataGridView();
            this.colMa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLoaiVaiTro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonVi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGiaMuc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlNav.SuspendLayout();
            this.pnlInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMuc)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlNav
            // 
            this.pnlNav.Controls.Add(this.btnNavQuyDinh);
            this.pnlNav.Controls.Add(this.btnNavDichVu);
            this.pnlNav.Controls.Add(this.btnNavLoaiTN);
            this.pnlNav.Controls.Add(this.btnNavNhanVien);
            this.pnlNav.Controls.Add(this.btnNavKhuVuc);
            this.pnlNav.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNav.Location = new System.Drawing.Point(0, 0);
            this.pnlNav.Name = "pnlNav";
            this.pnlNav.Size = new System.Drawing.Size(834, 45);
            this.pnlNav.TabIndex = 0;
            // 
            // btnNavQuyDinh
            // 
            this.btnNavQuyDinh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavQuyDinh.FlatAppearance.BorderSize = 0;
            this.btnNavQuyDinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavQuyDinh.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavQuyDinh.Location = new System.Drawing.Point(400, 10);
            this.btnNavQuyDinh.Name = "btnNavQuyDinh";
            this.btnNavQuyDinh.Size = new System.Drawing.Size(145, 30);
            this.btnNavQuyDinh.TabIndex = 4;
            this.btnNavQuyDinh.Text = "[ Quy định đền bù ]";
            this.btnNavQuyDinh.UseVisualStyleBackColor = true;
            this.btnNavQuyDinh.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // btnNavDichVu
            // 
            this.btnNavDichVu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavDichVu.FlatAppearance.BorderSize = 0;
            this.btnNavDichVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavDichVu.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavDichVu.Location = new System.Drawing.Point(305, 10);
            this.btnNavDichVu.Name = "btnNavDichVu";
            this.btnNavDichVu.Size = new System.Drawing.Size(90, 30);
            this.btnNavDichVu.TabIndex = 3;
            this.btnNavDichVu.Text = "[ Dịch vụ ]";
            this.btnNavDichVu.UseVisualStyleBackColor = true;
            this.btnNavDichVu.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // btnNavLoaiTN
            // 
            this.btnNavLoaiTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavLoaiTN.FlatAppearance.BorderSize = 0;
            this.btnNavLoaiTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavLoaiTN.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavLoaiTN.Location = new System.Drawing.Point(180, 10);
            this.btnNavLoaiTN.Name = "btnNavLoaiTN";
            this.btnNavLoaiTN.Size = new System.Drawing.Size(120, 30);
            this.btnNavLoaiTN.TabIndex = 2;
            this.btnNavLoaiTN.Text = "[ Loại tiện nghi ]";
            this.btnNavLoaiTN.UseVisualStyleBackColor = true;
            this.btnNavLoaiTN.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // btnNavNhanVien
            // 
            this.btnNavNhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavNhanVien.FlatAppearance.BorderSize = 0;
            this.btnNavNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavNhanVien.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavNhanVien.Location = new System.Drawing.Point(90, 10);
            this.btnNavNhanVien.Name = "btnNavNhanVien";
            this.btnNavNhanVien.Size = new System.Drawing.Size(85, 30);
            this.btnNavNhanVien.TabIndex = 1;
            this.btnNavNhanVien.Text = "[ Nhân viên ]";
            this.btnNavNhanVien.UseVisualStyleBackColor = true;
            this.btnNavNhanVien.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // btnNavKhuVuc
            // 
            this.btnNavKhuVuc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavKhuVuc.FlatAppearance.BorderSize = 0;
            this.btnNavKhuVuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavKhuVuc.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavKhuVuc.Location = new System.Drawing.Point(10, 10);
            this.btnNavKhuVuc.Name = "btnNavKhuVuc";
            this.btnNavKhuVuc.Size = new System.Drawing.Size(75, 30);
            this.btnNavKhuVuc.TabIndex = 0;
            this.btnNavKhuVuc.Text = "[ Khu vực ]";
            this.btnNavKhuVuc.UseVisualStyleBackColor = true;
            this.btnNavKhuVuc.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // pnlInput
            // 
            this.pnlInput.Controls.Add(this.btnThem);
            this.pnlInput.Controls.Add(this.txtExtra2);
            this.pnlInput.Controls.Add(this.lblExtra2);
            this.pnlInput.Controls.Add(this.txtExtra1);
            this.pnlInput.Controls.Add(this.lblExtra1);
            this.pnlInput.Controls.Add(this.txtTen);
            this.pnlInput.Controls.Add(this.lblTen);
            this.pnlInput.Controls.Add(this.txtMa);
            this.pnlInput.Controls.Add(this.lblMa);
            this.pnlInput.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlInput.Location = new System.Drawing.Point(0, 45);
            this.pnlInput.Name = "pnlInput";
            this.pnlInput.Size = new System.Drawing.Size(834, 55);
            this.pnlInput.TabIndex = 1;
            // 
            // btnThem
            // 
            this.btnThem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.Location = new System.Drawing.Point(725, 12);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(95, 28);
            this.btnThem.TabIndex = 8;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // txtExtra2
            // 
            this.txtExtra2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtra2.Location = new System.Drawing.Point(625, 14);
            this.txtExtra2.Name = "txtExtra2";
            this.txtExtra2.Size = new System.Drawing.Size(85, 25);
            this.txtExtra2.TabIndex = 7;
            // 
            // lblExtra2
            // 
            this.lblExtra2.AutoSize = true;
            this.lblExtra2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtra2.Location = new System.Drawing.Point(565, 17);
            this.lblExtra2.Name = "lblExtra2";
            this.lblExtra2.Size = new System.Drawing.Size(56, 17);
            this.lblExtra2.TabIndex = 6;
            this.lblExtra2.Text = "Đơn giá:";
            // 
            // txtExtra1
            // 
            this.txtExtra1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExtra1.Location = new System.Drawing.Point(465, 14);
            this.txtExtra1.Name = "txtExtra1";
            this.txtExtra1.Size = new System.Drawing.Size(90, 25);
            this.txtExtra1.TabIndex = 5;
            // 
            // lblExtra1
            // 
            this.lblExtra1.AutoSize = true;
            this.lblExtra1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtra1.Location = new System.Drawing.Point(365, 17);
            this.lblExtra1.Name = "lblExtra1";
            this.lblExtra1.Size = new System.Drawing.Size(97, 17);
            this.lblExtra1.TabIndex = 4;
            this.lblExtra1.Text = "Đơn vị / Vai trò:";
            // 
            // txtTen
            // 
            this.txtTen.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTen.Location = new System.Drawing.Point(190, 14);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(165, 25);
            this.txtTen.TabIndex = 3;
            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTen.Location = new System.Drawing.Point(155, 17);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(31, 17);
            this.lblTen.TabIndex = 2;
            this.lblTen.Text = "Tên:";
            // 
            // txtMa
            // 
            this.txtMa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMa.Location = new System.Drawing.Point(45, 14);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(100, 25);
            this.txtMa.TabIndex = 1;
            // 
            // lblMa
            // 
            this.lblMa.AutoSize = true;
            this.lblMa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMa.Location = new System.Drawing.Point(12, 17);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(30, 17);
            this.lblMa.TabIndex = 0;
            this.lblMa.Text = "Mã:";
            // 
            // dgvDanhMuc
            // 
            this.dgvDanhMuc.AllowUserToAddRows = false;
            this.dgvDanhMuc.AllowUserToDeleteRows = false;
            this.dgvDanhMuc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMuc.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDanhMuc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDanhMuc.ColumnHeadersHeight = 30;
            this.dgvDanhMuc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMa,
            this.colTen,
            this.colLoaiVaiTro,
            this.colDonVi,
            this.colDonGiaMuc});
            this.dgvDanhMuc.EnableHeadersVisualStyles = false;
            this.dgvDanhMuc.Location = new System.Drawing.Point(12, 110);
            this.dgvDanhMuc.MultiSelect = false;
            this.dgvDanhMuc.Name = "dgvDanhMuc";
            this.dgvDanhMuc.ReadOnly = true;
            this.dgvDanhMuc.RowHeadersVisible = false;
            this.dgvDanhMuc.RowTemplate.Height = 28;
            this.dgvDanhMuc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDanhMuc.Size = new System.Drawing.Size(810, 320);
            this.dgvDanhMuc.TabIndex = 2;
            this.dgvDanhMuc.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDanhMuc_CellClick);
            // 
            // colMa
            // 
            this.colMa.FillWeight = 80F;
            this.colMa.HeaderText = "Mã";
            this.colMa.Name = "colMa";
            this.colMa.ReadOnly = true;
            // 
            // colTen
            // 
            this.colTen.FillWeight = 120F;
            this.colTen.HeaderText = "Tên";
            this.colTen.Name = "colTen";
            this.colTen.ReadOnly = true;
            // 
            // colLoaiVaiTro
            // 
            this.colLoaiVaiTro.FillWeight = 100F;
            this.colLoaiVaiTro.HeaderText = "Loại / Vai trò";
            this.colLoaiVaiTro.Name = "colLoaiVaiTro";
            this.colLoaiVaiTro.ReadOnly = true;
            // 
            // colDonVi
            // 
            this.colDonVi.FillWeight = 80F;
            this.colDonVi.HeaderText = "Đơn vị";
            this.colDonVi.Name = "colDonVi";
            this.colDonVi.ReadOnly = true;
            // 
            // colDonGiaMuc
            // 
            this.colDonGiaMuc.FillWeight = 100F;
            this.colDonGiaMuc.HeaderText = "Đơn giá / Mức";
            this.colDonGiaMuc.Name = "colDonGiaMuc";
            this.colDonGiaMuc.ReadOnly = true;
            // 
            // FrmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(834, 441);
            this.Controls.Add(this.dgvDanhMuc);
            this.Controls.Add(this.pnlInput);
            this.Controls.Add(this.pnlNav);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh mục khách sạn";
            this.Load += new System.EventHandler(this.FrmDanhMuc_Load);
            this.pnlNav.ResumeLayout(false);
            this.pnlInput.ResumeLayout(false);
            this.pnlInput.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMuc)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlNav;
        private System.Windows.Forms.Button btnNavKhuVuc;
        private System.Windows.Forms.Button btnNavNhanVien;
        private System.Windows.Forms.Button btnNavLoaiTN;
        private System.Windows.Forms.Button btnNavDichVu;
        private System.Windows.Forms.Button btnNavQuyDinh;
        private System.Windows.Forms.Panel pnlInput;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label lblExtra1;
        private System.Windows.Forms.TextBox txtExtra1;
        private System.Windows.Forms.Label lblExtra2;
        private System.Windows.Forms.TextBox txtExtra2;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DataGridView dgvDanhMuc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMa;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLoaiVaiTro;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonVi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGiaMuc;
    }
}