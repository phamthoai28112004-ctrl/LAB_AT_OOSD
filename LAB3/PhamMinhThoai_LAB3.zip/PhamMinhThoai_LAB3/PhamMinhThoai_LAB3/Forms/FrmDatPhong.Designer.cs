﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmDatPhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTabKhachHang = new System.Windows.Forms.Label();
            this.lblTabDatPhong = new System.Windows.Forms.Label();
            this.lblTabNhanPhong = new System.Windows.Forms.Label();
            this.lblSoPhieuDat = new System.Windows.Forms.Label();
            this.txtSoPhieuDat = new System.Windows.Forms.TextBox();
            this.lblKhach = new System.Windows.Forms.Label();
            this.txtKhach = new System.Windows.Forms.TextBox();
            this.lblKenhDat = new System.Windows.Forms.Label();
            this.txtKenhDat = new System.Windows.Forms.TextBox();
            this.lblTienCoc = new System.Windows.Forms.Label();
            this.txtTienCoc = new System.Windows.Forms.TextBox();
            this.dgvPhongTrong = new System.Windows.Forms.DataGridView();
            this.dgvPhongChon = new System.Windows.Forms.DataGridView();
            this.btnLapPhieuDat = new System.Windows.Forms.Button();
            this.lblTitlePhieuDat = new System.Windows.Forms.Label();
            this.dgvPhieuDatPhong = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongTrong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongChon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuDatPhong)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTabKhachHang
            // 
            this.lblTabKhachHang.AutoSize = true;
            this.lblTabKhachHang.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTabKhachHang.Location = new System.Drawing.Point(20, 15);
            this.lblTabKhachHang.Name = "lblTabKhachHang";
            this.lblTabKhachHang.Size = new System.Drawing.Size(83, 17);
            this.lblTabKhachHang.TabIndex = 0;
            this.lblTabKhachHang.Text = "[Khách hàng]";
            // 
            // lblTabDatPhong
            // 
            this.lblTabDatPhong.AutoSize = true;
            this.lblTabDatPhong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTabDatPhong.Location = new System.Drawing.Point(109, 15);
            this.lblTabDatPhong.Name = "lblTabDatPhong";
            this.lblTabDatPhong.Size = new System.Drawing.Size(81, 17);
            this.lblTabDatPhong.TabIndex = 1;
            this.lblTabDatPhong.Text = "[Đặt phòng]";
            // 
            // lblTabNhanPhong
            // 
            this.lblTabNhanPhong.AutoSize = true;
            this.lblTabNhanPhong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTabNhanPhong.Location = new System.Drawing.Point(196, 15);
            this.lblTabNhanPhong.Name = "lblTabNhanPhong";
            this.lblTabNhanPhong.Size = new System.Drawing.Size(155, 17);
            this.lblTabNhanPhong.TabIndex = 2;
            this.lblTabNhanPhong.Text = "[Nhận phòng / Người lưu trú]";
            // 
            // lblSoPhieuDat
            // 
            this.lblSoPhieuDat.AutoSize = true;
            this.lblSoPhieuDat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoPhieuDat.Location = new System.Drawing.Point(20, 52);
            this.lblSoPhieuDat.Name = "lblSoPhieuDat";
            this.lblSoPhieuDat.Size = new System.Drawing.Size(84, 17);
            this.lblSoPhieuDat.TabIndex = 3;
            this.lblSoPhieuDat.Text = "Số phiếu đặt:";
            // 
            // txtSoPhieuDat
            // 
            this.txtSoPhieuDat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoPhieuDat.Location = new System.Drawing.Point(110, 49);
            this.txtSoPhieuDat.Name = "txtSoPhieuDat";
            this.txtSoPhieuDat.Size = new System.Drawing.Size(130, 25);
            this.txtSoPhieuDat.TabIndex = 4;
            this.txtSoPhieuDat.Text = "DP001";
            // 
            // lblKhach
            // 
            this.lblKhach.AutoSize = true;
            this.lblKhach.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKhach.Location = new System.Drawing.Point(260, 52);
            this.lblKhach.Name = "lblKhach";
            this.lblKhach.Size = new System.Drawing.Size(46, 17);
            this.lblKhach.TabIndex = 5;
            this.lblKhach.Text = "Khách:";
            // 
            // txtKhach
            // 
            this.txtKhach.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhach.Location = new System.Drawing.Point(312, 49);
            this.txtKhach.Name = "txtKhach";
            this.txtKhach.Size = new System.Drawing.Size(180, 25);
            this.txtKhach.TabIndex = 6;
            this.txtKhach.Text = "Nguyễn Văn A";
            // 
            // lblKenhDat
            // 
            this.lblKenhDat.AutoSize = true;
            this.lblKenhDat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKenhDat.Location = new System.Drawing.Point(510, 52);
            this.lblKenhDat.Name = "lblKenhDat";
            this.lblKenhDat.Size = new System.Drawing.Size(62, 17);
            this.lblKenhDat.TabIndex = 7;
            this.lblKenhDat.Text = "Kênh đặt:";
            // 
            // txtKenhDat
            // 
            this.txtKenhDat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKenhDat.Location = new System.Drawing.Point(578, 49);
            this.txtKenhDat.Name = "txtKenhDat";
            this.txtKenhDat.Size = new System.Drawing.Size(130, 25);
            this.txtKenhDat.TabIndex = 8;
            this.txtKenhDat.Text = "Website";
            // 
            // lblTienCoc
            // 
            this.lblTienCoc.AutoSize = true;
            this.lblTienCoc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTienCoc.Location = new System.Drawing.Point(725, 52);
            this.lblTienCoc.Name = "lblTienCoc";
            this.lblTienCoc.Size = new System.Drawing.Size(60, 17);
            this.lblTienCoc.TabIndex = 9;
            this.lblTienCoc.Text = "Tiền cọc:";
            // 
            // txtTienCoc
            // 
            this.txtTienCoc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTienCoc.Location = new System.Drawing.Point(791, 49);
            this.txtTienCoc.Name = "txtTienCoc";
            this.txtTienCoc.Size = new System.Drawing.Size(110, 25);
            this.txtTienCoc.TabIndex = 10;
            this.txtTienCoc.Text = "500000";
            // 
            // dgvPhongTrong
            // 
            this.dgvPhongTrong.AllowUserToAddRows = false;
            this.dgvPhongTrong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhongTrong.BackgroundColor = System.Drawing.Color.White;
            this.dgvPhongTrong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhongTrong.Location = new System.Drawing.Point(23, 90);
            this.dgvPhongTrong.Name = "dgvPhongTrong";
            this.dgvPhongTrong.ReadOnly = true;
            this.dgvPhongTrong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhongTrong.Size = new System.Drawing.Size(430, 200);
            this.dgvPhongTrong.TabIndex = 11;
            this.dgvPhongTrong.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPhongTrong_CellDoubleClick);
            // 
            // dgvPhongChon
            // 
            this.dgvPhongChon.AllowUserToAddRows = false;
            this.dgvPhongChon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhongChon.BackgroundColor = System.Drawing.Color.White;
            this.dgvPhongChon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhongChon.Location = new System.Drawing.Point(471, 90);
            this.dgvPhongChon.Name = "dgvPhongChon";
            this.dgvPhongChon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhongChon.Size = new System.Drawing.Size(430, 200);
            this.dgvPhongChon.TabIndex = 12;
            // 
            // btnLapPhieuDat
            // 
            this.btnLapPhieuDat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLapPhieuDat.Location = new System.Drawing.Point(761, 300);
            this.btnLapPhieuDat.Name = "btnLapPhieuDat";
            this.btnLapPhieuDat.Size = new System.Drawing.Size(140, 32);
            this.btnLapPhieuDat.TabIndex = 13;
            this.btnLapPhieuDat.Text = "Lập phiếu đặt";
            this.btnLapPhieuDat.UseVisualStyleBackColor = true;
            this.btnLapPhieuDat.Click += new System.EventHandler(this.btnLapPhieuDat_Click);
            // 
            // lblTitlePhieuDat
            // 
            this.lblTitlePhieuDat.AutoSize = true;
            this.lblTitlePhieuDat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitlePhieuDat.Location = new System.Drawing.Point(20, 320);
            this.lblTitlePhieuDat.Name = "lblTitlePhieuDat";
            this.lblTitlePhieuDat.Size = new System.Drawing.Size(107, 17);
            this.lblTitlePhieuDat.TabIndex = 14;
            this.lblTitlePhieuDat.Text = "Phiếu đặt phòng:";
            // 
            // dgvPhieuDatPhong
            // 
            this.dgvPhieuDatPhong.AllowUserToAddRows = false;
            this.dgvPhieuDatPhong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuDatPhong.BackgroundColor = System.Drawing.Color.White;
            this.dgvPhieuDatPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhieuDatPhong.Location = new System.Drawing.Point(23, 345);
            this.dgvPhieuDatPhong.Name = "dgvPhieuDatPhong";
            this.dgvPhieuDatPhong.ReadOnly = true;
            this.dgvPhieuDatPhong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhieuDatPhong.Size = new System.Drawing.Size(878, 180);
            this.dgvPhieuDatPhong.TabIndex = 15;
            // 
            // FrmDatPhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 545);
            this.Controls.Add(this.dgvPhieuDatPhong);
            this.Controls.Add(this.lblTitlePhieuDat);
            this.Controls.Add(this.btnLapPhieuDat);
            this.Controls.Add(this.dgvPhongChon);
            this.Controls.Add(this.dgvPhongTrong);
            this.Controls.Add(this.txtTienCoc);
            this.Controls.Add(this.lblTienCoc);
            this.Controls.Add(this.txtKenhDat);
            this.Controls.Add(this.lblKenhDat);
            this.Controls.Add(this.txtKhach);
            this.Controls.Add(this.lblKhach);
            this.Controls.Add(this.txtSoPhieuDat);
            this.Controls.Add(this.lblSoPhieuDat);
            this.Controls.Add(this.lblTabNhanPhong);
            this.Controls.Add(this.lblTabDatPhong);
            this.Controls.Add(this.lblTabKhachHang);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FrmDatPhong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Khách hàng - Đặt phòng - Nhận phòng";
            this.Load += new System.EventHandler(this.FrmDatPhong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongTrong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongChon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuDatPhong)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTabKhachHang;
        private System.Windows.Forms.Label lblTabDatPhong;
        private System.Windows.Forms.Label lblTabNhanPhong;
        private System.Windows.Forms.Label lblSoPhieuDat;
        private System.Windows.Forms.TextBox txtSoPhieuDat;
        private System.Windows.Forms.Label lblKhach;
        private System.Windows.Forms.TextBox txtKhach;
        private System.Windows.Forms.Label lblKenhDat;
        private System.Windows.Forms.TextBox txtKenhDat;
        private System.Windows.Forms.Label lblTienCoc;
        private System.Windows.Forms.TextBox txtTienCoc;
        private System.Windows.Forms.DataGridView dgvPhongTrong;
        private System.Windows.Forms.DataGridView dgvPhongChon;
        private System.Windows.Forms.Button btnLapPhieuDat;
        private System.Windows.Forms.Label lblTitlePhieuDat;
        private System.Windows.Forms.DataGridView dgvPhieuDatPhong;
    }
}