﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan
{
    public partial class FrmThongKe : Form
    {
        private readonly ThongKeService _thongKeService;

        public FrmThongKe()
        {
            InitializeComponent();
            _thongKeService = new ThongKeService();
        }

        private void FrmThongKe_Load(object sender, EventArgs e)
        {
            // Thiết lập mặc định từ đầu tháng hiện tại đến ngày hiện tại
            DateTime now = DateTime.Now;
            dtpTuNgay.Value = new DateTime(now.Year, now.Month, 1);
            dtpDenNgay.Value = now;

            ThongKeData();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            ThongKeData();
        }

        private void ThongKeData()
        {
            try
            {
                DateTime tuNgay = dtpTuNgay.Value;
                DateTime denNgay = dtpDenNgay.Value;

                if (tuNgay > denNgay)
                {
                    MessageBox.Show("Từ ngày không được lớn hơn Đến ngày!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 1. Tải chỉ số tổng quan
                DataTable dtTongQuan = _thongKeService.LayThongKeTongQuan(tuNgay, denNgay);
                if (dtTongQuan.Rows.Count > 0)
                {
                    DataRow row = dtTongQuan.Rows[0];
                    int soPhieuDat = Convert.ToInt32(row["SoPhieuDat"]);
                    int dangO = Convert.ToInt32(row["DangO"]);
                    int soHoaDon = Convert.ToInt32(row["SoHoaDon"]);
                    decimal doanhThuHD = Convert.ToDecimal(row["DoanhThuHD"]);
                    decimal tongDenBu = Convert.ToDecimal(row["TongDenBu"]);

                    lblPhieuDat.Text = $"Phiếu đặt: {soPhieuDat}";
                    lblDangO.Text = $"Đang ở: {dangO}";
                    lblHoaDon.Text = $"Hóa đơn: {soHoaDon}";
                    lblDoanhThuHD.Text = $"Doanh thu HĐ: {doanhThuHD:#,##0} đ";
                    lblTongDenBu.Text = $"Tổng đền bù: {tongDenBu:#,##0} đ";
                }

                // 2. Tải danh sách dịch vụ
                DataTable dtDichVu = _thongKeService.LayThongKeDichVu(tuNgay, denNgay);
                dgvDichVu.DataSource = dtDichVu;

                // Định dạng hiển thị DataGridView
                if (dgvDichVu.Columns["Tổng tiền"] != null)
                {
                    dgvDichVu.Columns["Tổng tiền"].DefaultCellStyle.Format = "#,##0 đ";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu thống kê: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}