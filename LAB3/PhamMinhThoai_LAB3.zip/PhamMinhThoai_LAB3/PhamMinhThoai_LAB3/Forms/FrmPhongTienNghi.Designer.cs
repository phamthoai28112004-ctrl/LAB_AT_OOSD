﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmPhongTienNghi
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlNav = new System.Windows.Forms.Panel();
            this.btnNavLapDat = new System.Windows.Forms.Button();
            this.btnNavTienNghi = new System.Windows.Forms.Button();
            this.btnNavPhong = new System.Windows.Forms.Button();
            this.pnlTopInput = new System.Windows.Forms.Panel();
            this.txtDonGiaNgay = new System.Windows.Forms.TextBox();
            this.lblDonGiaNgay = new System.Windows.Forms.Label();
            this.txtSoNguoiToiDa = new System.Windows.Forms.TextBox();
            this.lblSoNguoiToiDa = new System.Windows.Forms.Label();
            this.txtKhuVuc = new System.Windows.Forms.TextBox();
            this.lblKhuVuc = new System.Windows.Forms.Label();
            this.txtSoPhong = new System.Windows.Forms.TextBox();
            this.lblSoPhong = new System.Windows.Forms.Label();
            this.dgvPhongTienNghi = new System.Windows.Forms.DataGridView();
            this.pnlBottomInput = new System.Windows.Forms.Panel();
            this.btnLapPhieu = new System.Windows.Forms.Button();
            this.txtTinhTrang = new System.Windows.Forms.TextBox();
            this.lblTinhTrang = new System.Windows.Forms.Label();
            this.txtPhongBottom = new System.Windows.Forms.TextBox();
            this.lblPhongBottom = new System.Windows.Forms.Label();
            this.txtTienNghi = new System.Windows.Forms.TextBox();
            this.lblTienNghi = new System.Windows.Forms.Label();
            this.txtPhieuLapDat = new System.Windows.Forms.TextBox();
            this.lblPhieuLapDat = new System.Windows.Forms.Label();
            this.pnlNav.SuspendLayout();
            this.pnlTopInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongTienNghi)).BeginInit();
            this.pnlBottomInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlNav
            // 
            this.pnlNav.Controls.Add(this.btnNavLapDat);
            this.pnlNav.Controls.Add(this.btnNavTienNghi);
            this.pnlNav.Controls.Add(this.btnNavPhong);
            this.pnlNav.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNav.Location = new System.Drawing.Point(0, 0);
            this.pnlNav.Name = "pnlNav";
            this.pnlNav.Size = new System.Drawing.Size(834, 40);
            this.pnlNav.TabIndex = 0;
            // 
            // btnNavLapDat
            // 
            this.btnNavLapDat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavLapDat.FlatAppearance.BorderSize = 0;
            this.btnNavLapDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavLapDat.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavLapDat.Location = new System.Drawing.Point(170, 8);
            this.btnNavLapDat.Name = "btnNavLapDat";
            this.btnNavLapDat.Size = new System.Drawing.Size(160, 28);
            this.btnNavLapDat.TabIndex = 2;
            this.btnNavLapDat.Text = "[Lắp đặt / luân chuyển]";
            this.btnNavLapDat.UseVisualStyleBackColor = true;
            this.btnNavLapDat.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // btnNavTienNghi
            // 
            this.btnNavTienNghi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavTienNghi.FlatAppearance.BorderSize = 0;
            this.btnNavTienNghi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavTienNghi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavTienNghi.Location = new System.Drawing.Point(85, 8);
            this.btnNavTienNghi.Name = "btnNavTienNghi";
            this.btnNavTienNghi.Size = new System.Drawing.Size(80, 28);
            this.btnNavTienNghi.TabIndex = 1;
            this.btnNavTienNghi.Text = "[Tiện nghi]";
            this.btnNavTienNghi.UseVisualStyleBackColor = true;
            this.btnNavTienNghi.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // btnNavPhong
            // 
            this.btnNavPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavPhong.FlatAppearance.BorderSize = 0;
            this.btnNavPhong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavPhong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavPhong.Location = new System.Drawing.Point(10, 8);
            this.btnNavPhong.Name = "btnNavPhong";
            this.btnNavPhong.Size = new System.Drawing.Size(70, 28);
            this.btnNavPhong.TabIndex = 0;
            this.btnNavPhong.Text = "[Phòng]";
            this.btnNavPhong.UseVisualStyleBackColor = true;
            this.btnNavPhong.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // pnlTopInput
            // 
            this.pnlTopInput.Controls.Add(this.txtDonGiaNgay);
            this.pnlTopInput.Controls.Add(this.lblDonGiaNgay);
            this.pnlTopInput.Controls.Add(this.txtSoNguoiToiDa);
            this.pnlTopInput.Controls.Add(this.lblSoNguoiToiDa);
            this.pnlTopInput.Controls.Add(this.txtKhuVuc);
            this.pnlTopInput.Controls.Add(this.lblKhuVuc);
            this.pnlTopInput.Controls.Add(this.txtSoPhong);
            this.pnlTopInput.Controls.Add(this.lblSoPhong);
            this.pnlTopInput.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopInput.Location = new System.Drawing.Point(0, 40);
            this.pnlTopInput.Name = "pnlTopInput";
            this.pnlTopInput.Size = new System.Drawing.Size(834, 45);
            this.pnlTopInput.TabIndex = 1;
            // 
            // txtDonGiaNgay
            // 
            this.txtDonGiaNgay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonGiaNgay.Location = new System.Drawing.Point(725, 10);
            this.txtDonGiaNgay.Name = "txtDonGiaNgay";
            this.txtDonGiaNgay.Size = new System.Drawing.Size(95, 25);
            this.txtDonGiaNgay.TabIndex = 7;
            this.txtDonGiaNgay.Text = "600000";
            // 
            // lblDonGiaNgay
            // 
            this.lblDonGiaNgay.AutoSize = true;
            this.lblDonGiaNgay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDonGiaNgay.Location = new System.Drawing.Point(628, 13);
            this.lblDonGiaNgay.Name = "lblDonGiaNgay";
            this.lblDonGiaNgay.Size = new System.Drawing.Size(94, 17);
            this.lblDonGiaNgay.TabIndex = 6;
            this.lblDonGiaNgay.Text = "Đơn giá/ngày:";
            // 
            // txtSoNguoiToiDa
            // 
            this.txtSoNguoiToiDa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoNguoiToiDa.Location = new System.Drawing.Point(552, 10);
            this.txtSoNguoiToiDa.Name = "txtSoNguoiToiDa";
            this.txtSoNguoiToiDa.Size = new System.Drawing.Size(70, 25);
            this.txtSoNguoiToiDa.TabIndex = 5;
            this.txtSoNguoiToiDa.Text = "2";
            // 
            // lblSoNguoiToiDa
            // 
            this.lblSoNguoiToiDa.AutoSize = true;
            this.lblSoNguoiToiDa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoNguoiToiDa.Location = new System.Drawing.Point(445, 13);
            this.lblSoNguoiToiDa.Name = "lblSoNguoiToiDa";
            this.lblSoNguoiToiDa.Size = new System.Drawing.Size(104, 17);
            this.lblSoNguoiToiDa.TabIndex = 4;
            this.lblSoNguoiToiDa.Text = "Số người tối đa:";
            // 
            // txtKhuVuc
            // 
            this.txtKhuVuc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhuVuc.Location = new System.Drawing.Point(305, 10);
            this.txtKhuVuc.Name = "txtKhuVuc";
            this.txtKhuVuc.Size = new System.Drawing.Size(130, 25);
            this.txtKhuVuc.TabIndex = 3;
            this.txtKhuVuc.Text = "Khu A";
            // 
            // lblKhuVuc
            // 
            this.lblKhuVuc.AutoSize = true;
            this.lblKhuVuc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKhuVuc.Location = new System.Drawing.Point(242, 13);
            this.lblKhuVuc.Name = "lblKhuVuc";
            this.lblKhuVuc.Size = new System.Drawing.Size(60, 17);
            this.lblKhuVuc.TabIndex = 2;
            this.lblKhuVuc.Text = "Khu vực:";
            // 
            // txtSoPhong
            // 
            this.txtSoPhong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoPhong.Location = new System.Drawing.Point(100, 10);
            this.txtSoPhong.Name = "txtSoPhong";
            this.txtSoPhong.Size = new System.Drawing.Size(130, 25);
            this.txtSoPhong.TabIndex = 1;
            this.txtSoPhong.Text = "A101";
            // 
            // lblSoPhong
            // 
            this.lblSoPhong.AutoSize = true;
            this.lblSoPhong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoPhong.Location = new System.Drawing.Point(12, 13);
            this.lblSoPhong.Name = "lblSoPhong";
            this.lblSoPhong.Size = new System.Drawing.Size(68, 17);
            this.lblSoPhong.TabIndex = 0;
            this.lblSoPhong.Text = "Số phòng:";
            // 
            // dgvPhongTienNghi
            // 
            this.dgvPhongTienNghi.AllowUserToAddRows = false;
            this.dgvPhongTienNghi.AllowUserToDeleteRows = false;
            this.dgvPhongTienNghi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhongTienNghi.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPhongTienNghi.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPhongTienNghi.ColumnHeadersHeight = 30;
            this.dgvPhongTienNghi.EnableHeadersVisualStyles = false;
            this.dgvPhongTienNghi.Location = new System.Drawing.Point(12, 90);
            this.dgvPhongTienNghi.MultiSelect = false;
            this.dgvPhongTienNghi.Name = "dgvPhongTienNghi";
            this.dgvPhongTienNghi.ReadOnly = true;
            this.dgvPhongTienNghi.RowHeadersVisible = false;
            this.dgvPhongTienNghi.RowTemplate.Height = 28;
            this.dgvPhongTienNghi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhongTienNghi.Size = new System.Drawing.Size(810, 250);
            this.dgvPhongTienNghi.TabIndex = 2;
            this.dgvPhongTienNghi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPhongTienNghi_CellClick);
            // 
            // pnlBottomInput
            // 
            this.pnlBottomInput.Controls.Add(this.btnLapPhieu);
            this.pnlBottomInput.Controls.Add(this.txtTinhTrang);
            this.pnlBottomInput.Controls.Add(this.lblTinhTrang);
            this.pnlBottomInput.Controls.Add(this.txtPhongBottom);
            this.pnlBottomInput.Controls.Add(this.lblPhongBottom);
            this.pnlBottomInput.Controls.Add(this.txtTienNghi);
            this.pnlBottomInput.Controls.Add(this.lblTienNghi);
            this.pnlBottomInput.Controls.Add(this.txtPhieuLapDat);
            this.pnlBottomInput.Controls.Add(this.lblPhieuLapDat);
            this.pnlBottomInput.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottomInput.Location = new System.Drawing.Point(0, 345);
            this.pnlBottomInput.Name = "pnlBottomInput";
            this.pnlBottomInput.Size = new System.Drawing.Size(834, 96);
            this.pnlBottomInput.TabIndex = 3;
            // 
            // btnLapPhieu
            // 
            this.btnLapPhieu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLapPhieu.Location = new System.Drawing.Point(695, 52);
            this.btnLapPhieu.Name = "btnLapPhieu";
            this.btnLapPhieu.Size = new System.Drawing.Size(125, 32);
            this.btnLapPhieu.TabIndex = 8;
            this.btnLapPhieu.Text = "Lập phiếu";
            this.btnLapPhieu.UseVisualStyleBackColor = true;
            this.btnLapPhieu.Click += new System.EventHandler(this.btnLapPhieu_Click);
            // 
            // txtTinhTrang
            // 
            this.txtTinhTrang.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTinhTrang.Location = new System.Drawing.Point(695, 15);
            this.txtTinhTrang.Name = "txtTinhTrang";
            this.txtTinhTrang.Size = new System.Drawing.Size(125, 25);
            this.txtTinhTrang.TabIndex = 7;
            this.txtTinhTrang.Text = "Tốt";
            // 
            // lblTinhTrang
            // 
            this.lblTinhTrang.AutoSize = true;
            this.lblTinhTrang.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTinhTrang.Location = new System.Drawing.Point(620, 18);
            this.lblTinhTrang.Name = "lblTinhTrang";
            this.lblTinhTrang.Size = new System.Drawing.Size(70, 17);
            this.lblTinhTrang.TabIndex = 6;
            this.lblTinhTrang.Text = "Tình trạng:";
            // 
            // txtPhongBottom
            // 
            this.txtPhongBottom.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhongBottom.Location = new System.Drawing.Point(505, 15);
            this.txtPhongBottom.Name = "txtPhongBottom";
            this.txtPhongBottom.Size = new System.Drawing.Size(100, 25);
            this.txtPhongBottom.TabIndex = 5;
            this.txtPhongBottom.Text = "A101";
            // 
            // lblPhongBottom
            // 
            this.lblPhongBottom.AutoSize = true;
            this.lblPhongBottom.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhongBottom.Location = new System.Drawing.Point(450, 18);
            this.lblPhongBottom.Name = "lblPhongBottom";
            this.lblPhongBottom.Size = new System.Drawing.Size(48, 17);
            this.lblPhongBottom.TabIndex = 4;
            this.lblPhongBottom.Text = "Phòng:";
            // 
            // txtTienNghi
            // 
            this.txtTienNghi.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTienNghi.Location = new System.Drawing.Point(335, 15);
            this.txtTienNghi.Name = "txtTienNghi";
            this.txtTienNghi.Size = new System.Drawing.Size(100, 25);
            this.txtTienNghi.TabIndex = 3;
            this.txtTienNghi.Text = "TV01";
            // 
            // lblTienNghi
            // 
            this.lblTienNghi.AutoSize = true;
            this.lblTienNghi.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTienNghi.Location = new System.Drawing.Point(265, 18);
            this.lblTienNghi.Name = "lblTienNghi";
            this.lblTienNghi.Size = new System.Drawing.Size(63, 17);
            this.lblTienNghi.TabIndex = 2;
            this.lblTienNghi.Text = "Tiện nghi:";
            // 
            // txtPhieuLapDat
            // 
            this.txtPhieuLapDat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhieuLapDat.Location = new System.Drawing.Point(115, 15);
            this.txtPhieuLapDat.Name = "txtPhieuLapDat";
            this.txtPhieuLapDat.Size = new System.Drawing.Size(135, 25);
            this.txtPhieuLapDat.TabIndex = 1;
            this.txtPhieuLapDat.Text = "LD001";
            // 
            // lblPhieuLapDat
            // 
            this.lblPhieuLapDat.AutoSize = true;
            this.lblPhieuLapDat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhieuLapDat.Location = new System.Drawing.Point(12, 18);
            this.lblPhieuLapDat.Name = "lblPhieuLapDat";
            this.lblPhieuLapDat.Size = new System.Drawing.Size(89, 17);
            this.lblPhieuLapDat.TabIndex = 0;
            this.lblPhieuLapDat.Text = "Phiếu lắp đặt:";
            // 
            // FrmPhongTienNghi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(834, 441);
            this.Controls.Add(this.pnlBottomInput);
            this.Controls.Add(this.dgvPhongTienNghi);
            this.Controls.Add(this.pnlTopInput);
            this.Controls.Add(this.pnlNav);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmPhongTienNghi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phòng - Tiện nghi - Phiếu lắp đặt";
            this.Load += new System.EventHandler(this.FrmPhongTienNghi_Load);
            this.pnlNav.ResumeLayout(false);
            this.pnlTopInput.ResumeLayout(false);
            this.pnlTopInput.PerformLayout();

            // SỬA TẠI ĐÂY: Thay BeginInit() bằng EndInit()
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongTienNghi)).EndInit();

            this.pnlBottomInput.ResumeLayout(false);
            this.pnlBottomInput.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlNav;
        private System.Windows.Forms.Button btnNavPhong;
        private System.Windows.Forms.Button btnNavTienNghi;
        private System.Windows.Forms.Button btnNavLapDat;
        private System.Windows.Forms.Panel pnlTopInput;
        private System.Windows.Forms.Label lblSoPhong;
        private System.Windows.Forms.TextBox txtSoPhong;
        private System.Windows.Forms.Label lblKhuVuc;
        private System.Windows.Forms.TextBox txtKhuVuc;
        private System.Windows.Forms.Label lblSoNguoiToiDa;
        private System.Windows.Forms.TextBox txtSoNguoiToiDa;
        private System.Windows.Forms.Label lblDonGiaNgay;
        private System.Windows.Forms.TextBox txtDonGiaNgay;
        private System.Windows.Forms.DataGridView dgvPhongTienNghi;
        private System.Windows.Forms.Panel pnlBottomInput;
        private System.Windows.Forms.Label lblPhieuLapDat;
        private System.Windows.Forms.TextBox txtPhieuLapDat;
        private System.Windows.Forms.Label lblTienNghi;
        private System.Windows.Forms.TextBox txtTienNghi;
        private System.Windows.Forms.Label lblPhongBottom;
        private System.Windows.Forms.TextBox txtPhongBottom;
        private System.Windows.Forms.Label lblTinhTrang;
        private System.Windows.Forms.TextBox txtTinhTrang;
        private System.Windows.Forms.Button btnLapPhieu;
    }
}