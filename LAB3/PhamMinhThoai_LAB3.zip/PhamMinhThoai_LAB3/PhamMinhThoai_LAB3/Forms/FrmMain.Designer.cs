﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnDanhMuc = new System.Windows.Forms.Button();
            this.btnPhongTienNghi = new System.Windows.Forms.Button();
            this.btnDatNhanPhong = new System.Windows.Forms.Button();
            this.btnSuDungDichVu = new System.Windows.Forms.Button();
            this.btnTraPhongThanhToan = new System.Windows.Forms.Button();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(56)))), ((int)(((byte)(96)))));
            this.lblTitle.Location = new System.Drawing.Point(12, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(780, 45);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "HỆ THỐNG QUẢN LÝ KHÁCH SẠN";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDanhMuc
            // 
            this.btnDanhMuc.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDanhMuc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDanhMuc.Location = new System.Drawing.Point(45, 110);
            this.btnDanhMuc.Name = "btnDanhMuc";
            this.btnDanhMuc.Size = new System.Drawing.Size(225, 70);
            this.btnDanhMuc.TabIndex = 1;
            this.btnDanhMuc.Text = "Danh mục";
            this.btnDanhMuc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDanhMuc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDanhMuc.UseVisualStyleBackColor = true;
            this.btnDanhMuc.Click += new System.EventHandler(this.btnDanhMuc_Click);
            // 
            // btnPhongTienNghi
            // 
            this.btnPhongTienNghi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhongTienNghi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPhongTienNghi.Location = new System.Drawing.Point(290, 110);
            this.btnPhongTienNghi.Name = "btnPhongTienNghi";
            this.btnPhongTienNghi.Size = new System.Drawing.Size(225, 70);
            this.btnPhongTienNghi.TabIndex = 2;
            this.btnPhongTienNghi.Text = "Phòng - Tiện nghi";
            this.btnPhongTienNghi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPhongTienNghi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPhongTienNghi.UseVisualStyleBackColor = true;
            this.btnPhongTienNghi.Click += new System.EventHandler(this.btnPhongTienNghi_Click);
            // 
            // btnDatNhanPhong
            // 
            this.btnDatNhanPhong.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatNhanPhong.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDatNhanPhong.Location = new System.Drawing.Point(535, 110);
            this.btnDatNhanPhong.Name = "btnDatNhanPhong";
            this.btnDatNhanPhong.Size = new System.Drawing.Size(225, 70);
            this.btnDatNhanPhong.TabIndex = 3;
            this.btnDatNhanPhong.Text = "Đặt / Nhận phòng";
            this.btnDatNhanPhong.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDatNhanPhong.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDatNhanPhong.UseVisualStyleBackColor = true;
            this.btnDatNhanPhong.Click += new System.EventHandler(this.btnDatNhanPhong_Click);
            // 
            // btnSuDungDichVu
            // 
            this.btnSuDungDichVu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuDungDichVu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSuDungDichVu.Location = new System.Drawing.Point(45, 195);
            this.btnSuDungDichVu.Name = "btnSuDungDichVu";
            this.btnSuDungDichVu.Size = new System.Drawing.Size(225, 70);
            this.btnSuDungDichVu.TabIndex = 4;
            this.btnSuDungDichVu.Text = "Sử dụng dịch vụ";
            this.btnSuDungDichVu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSuDungDichVu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSuDungDichVu.UseVisualStyleBackColor = true;
            this.btnSuDungDichVu.Click += new System.EventHandler(this.btnSuDungDichVu_Click);
            // 
            // btnTraPhongThanhToan
            // 
            this.btnTraPhongThanhToan.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTraPhongThanhToan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTraPhongThanhToan.Location = new System.Drawing.Point(290, 195);
            this.btnTraPhongThanhToan.Name = "btnTraPhongThanhToan";
            this.btnTraPhongThanhToan.Size = new System.Drawing.Size(225, 70);
            this.btnTraPhongThanhToan.TabIndex = 5;
            this.btnTraPhongThanhToan.Text = "Trả phòng - Thanh toán";
            this.btnTraPhongThanhToan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnTraPhongThanhToan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTraPhongThanhToan.UseVisualStyleBackColor = true;
            this.btnTraPhongThanhToan.Click += new System.EventHandler(this.btnTraPhongThanhToan_Click);
            // 
            // btnThongKe
            // 
            this.btnThongKe.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKe.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThongKe.Location = new System.Drawing.Point(535, 195);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(225, 70);
            this.btnThongKe.TabIndex = 6;
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnThongKe.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThongKe.UseVisualStyleBackColor = true;
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThoat.Location = new System.Drawing.Point(290, 280);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(225, 70);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnThoat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(804, 381);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnThongKe);
            this.Controls.Add(this.btnTraPhongThanhToan);
            this.Controls.Add(this.btnSuDungDichVu);
            this.Controls.Add(this.btnDatNhanPhong);
            this.Controls.Add(this.btnPhongTienNghi);
            this.Controls.Add(this.btnDanhMuc);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý khách sạn";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnDanhMuc;
        private System.Windows.Forms.Button btnPhongTienNghi;
        private System.Windows.Forms.Button btnDatNhanPhong;
        private System.Windows.Forms.Button btnSuDungDichVu;
        private System.Windows.Forms.Button btnTraPhongThanhToan;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.Button btnThoat;
    }
}