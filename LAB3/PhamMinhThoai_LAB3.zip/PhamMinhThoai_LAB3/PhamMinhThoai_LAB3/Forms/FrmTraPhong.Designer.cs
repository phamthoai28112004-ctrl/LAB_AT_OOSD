﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmTraPhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPhieuDangO = new System.Windows.Forms.Label();
            this.txtPhieuDangO = new System.Windows.Forms.TextBox();
            this.dgvPhong = new System.Windows.Forms.DataGridView();
            this.dgvTienNghi = new System.Windows.Forms.DataGridView();
            this.dgvTienNghiDenBu = new System.Windows.Forms.DataGridView();
            this.lblSoPhieuDenBu = new System.Windows.Forms.Label();
            this.txtSoPhieuDenBu = new System.Windows.Forms.TextBox();
            this.lblMucDo = new System.Windows.Forms.Label();
            this.txtMucDo = new System.Windows.Forms.TextBox();
            this.lblSoTienDenBu = new System.Windows.Forms.Label();
            this.txtSoTienDenBu = new System.Windows.Forms.TextBox();
            this.btnLapPhieuDenBu = new System.Windows.Forms.Button();
            this.lblSoHoaDon = new System.Windows.Forms.Label();
            this.txtSoHoaDon = new System.Windows.Forms.TextBox();
            this.lblSoNgayTinhTien = new System.Windows.Forms.Label();
            this.txtSoNgayTinhTien = new System.Windows.Forms.TextBox();
            this.btnLapHoaDon = new System.Windows.Forms.Button();
            this.dgvHoaDon = new System.Windows.Forms.DataGridView();
            this.lblHinhThuc = new System.Windows.Forms.Label();
            this.txtHinhThuc = new System.Windows.Forms.TextBox();
            this.lblSoTienThanhToan = new System.Windows.Forms.Label();
            this.txtSoTienThanhToan = new System.Windows.Forms.TextBox();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnHoanTatTraPhong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNghi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNghiDenBu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPhieuDangO
            // 
            this.lblPhieuDangO.AutoSize = true;
            this.lblPhieuDangO.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhieuDangO.Location = new System.Drawing.Point(30, 20);
            this.lblPhieuDangO.Name = "lblPhieuDangO";
            this.lblPhieuDangO.Size = new System.Drawing.Size(91, 17);
            this.lblPhieuDangO.TabIndex = 0;
            this.lblPhieuDangO.Text = "Phiếu đang ở:";
            // 
            // txtPhieuDangO
            // 
            this.txtPhieuDangO.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhieuDangO.Location = new System.Drawing.Point(135, 17);
            this.txtPhieuDangO.Name = "txtPhieuDangO";
            this.txtPhieuDangO.Size = new System.Drawing.Size(130, 25);
            this.txtPhieuDangO.TabIndex = 1;
            this.txtPhieuDangO.Text = "DP001";
            this.txtPhieuDangO.Leave += new System.EventHandler(this.txtPhieuDangO_Leave);
            // 
            // dgvPhong
            // 
            this.dgvPhong.AllowUserToAddRows = false;
            this.dgvPhong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhong.BackgroundColor = System.Drawing.Color.White;
            this.dgvPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhong.Location = new System.Drawing.Point(30, 55);
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.ReadOnly = true;
            this.dgvPhong.Size = new System.Drawing.Size(260, 160);
            this.dgvPhong.TabIndex = 2;
            // 
            // dgvTienNghi
            // 
            this.dgvTienNghi.AllowUserToAddRows = false;
            this.dgvTienNghi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTienNghi.BackgroundColor = System.Drawing.Color.White;
            this.dgvTienNghi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTienNghi.Location = new System.Drawing.Point(305, 55);
            this.dgvTienNghi.Name = "dgvTienNghi";
            this.dgvTienNghi.ReadOnly = true;
            this.dgvTienNghi.Size = new System.Drawing.Size(275, 160);
            this.dgvTienNghi.TabIndex = 3;
            // 
            // dgvTienNghiDenBu
            // 
            this.dgvTienNghiDenBu.AllowUserToAddRows = false;
            this.dgvTienNghiDenBu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTienNghiDenBu.BackgroundColor = System.Drawing.Color.White;
            this.dgvTienNghiDenBu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTienNghiDenBu.Location = new System.Drawing.Point(595, 55);
            this.dgvTienNghiDenBu.Name = "dgvTienNghiDenBu";
            this.dgvTienNghiDenBu.ReadOnly = true;
            this.dgvTienNghiDenBu.Size = new System.Drawing.Size(275, 160);
            this.dgvTienNghiDenBu.TabIndex = 4;
            // 
            // lblSoPhieuDenBu
            // 
            this.lblSoPhieuDenBu.AutoSize = true;
            this.lblSoPhieuDenBu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoPhieuDenBu.Location = new System.Drawing.Point(27, 235);
            this.lblSoPhieuDenBu.Name = "lblSoPhieuDenBu";
            this.lblSoPhieuDenBu.Size = new System.Drawing.Size(107, 17);
            this.lblSoPhieuDenBu.TabIndex = 5;
            this.lblSoPhieuDenBu.Text = "Số phiếu đền bù:";
            // 
            // txtSoPhieuDenBu
            // 
            this.txtSoPhieuDenBu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoPhieuDenBu.Location = new System.Drawing.Point(140, 232);
            this.txtSoPhieuDenBu.Name = "txtSoPhieuDenBu";
            this.txtSoPhieuDenBu.Size = new System.Drawing.Size(120, 25);
            this.txtSoPhieuDenBu.TabIndex = 6;
            this.txtSoPhieuDenBu.Text = "DB001";
            // 
            // lblMucDo
            // 
            this.lblMucDo.AutoSize = true;
            this.lblMucDo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMucDo.Location = new System.Drawing.Point(280, 235);
            this.lblMucDo.Name = "lblMucDo";
            this.lblMucDo.Size = new System.Drawing.Size(56, 17);
            this.lblMucDo.TabIndex = 7;
            this.lblMucDo.Text = "Mức độ:";
            // 
            // txtMucDo
            // 
            this.txtMucDo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMucDo.Location = new System.Drawing.Point(340, 232);
            this.txtMucDo.Name = "txtMucDo";
            this.txtMucDo.Size = new System.Drawing.Size(130, 25);
            this.txtMucDo.TabIndex = 8;
            this.txtMucDo.Text = "Hư hỏng nhẹ";
            // 
            // lblSoTienDenBu
            // 
            this.lblSoTienDenBu.AutoSize = true;
            this.lblSoTienDenBu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoTienDenBu.Location = new System.Drawing.Point(495, 235);
            this.lblSoTienDenBu.Name = "lblSoTienDenBu";
            this.lblSoTienDenBu.Size = new System.Drawing.Size(51, 17);
            this.lblSoTienDenBu.TabIndex = 9;
            this.lblSoTienDenBu.Text = "Số tiền:";
            // 
            // txtSoTienDenBu
            // 
            this.txtSoTienDenBu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoTienDenBu.Location = new System.Drawing.Point(550, 232);
            this.txtSoTienDenBu.Name = "txtSoTienDenBu";
            this.txtSoTienDenBu.Size = new System.Drawing.Size(115, 25);
            this.txtSoTienDenBu.TabIndex = 10;
            this.txtSoTienDenBu.Text = "500000";
            // 
            // btnLapPhieuDenBu
            // 
            this.btnLapPhieuDenBu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLapPhieuDenBu.Location = new System.Drawing.Point(705, 228);
            this.btnLapPhieuDenBu.Name = "btnLapPhieuDenBu";
            this.btnLapPhieuDenBu.Size = new System.Drawing.Size(145, 30);
            this.btnLapPhieuDenBu.TabIndex = 11;
            this.btnLapPhieuDenBu.Text = "Lập phiếu đền bù";
            this.btnLapPhieuDenBu.UseVisualStyleBackColor = true;
            this.btnLapPhieuDenBu.Click += new System.EventHandler(this.btnLapPhieuDenBu_Click);
            // 
            // lblSoHoaDon
            // 
            this.lblSoHoaDon.AutoSize = true;
            this.lblSoHoaDon.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoHoaDon.Location = new System.Drawing.Point(27, 280);
            this.lblSoHoaDon.Name = "lblSoHoaDon";
            this.lblSoHoaDon.Size = new System.Drawing.Size(79, 17);
            this.lblSoHoaDon.TabIndex = 12;
            this.lblSoHoaDon.Text = "Số hóa đơn:";
            // 
            // txtSoHoaDon
            // 
            this.txtSoHoaDon.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoHoaDon.Location = new System.Drawing.Point(120, 277);
            this.txtSoHoaDon.Name = "txtSoHoaDon";
            this.txtSoHoaDon.Size = new System.Drawing.Size(120, 25);
            this.txtSoHoaDon.TabIndex = 13;
            this.txtSoHoaDon.Text = "HD001";
            // 
            // lblSoNgayTinhTien
            // 
            this.lblSoNgayTinhTien.AutoSize = true;
            this.lblSoNgayTinhTien.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoNgayTinhTien.Location = new System.Drawing.Point(265, 280);
            this.lblSoNgayTinhTien.Name = "lblSoNgayTinhTien";
            this.lblSoNgayTinhTien.Size = new System.Drawing.Size(110, 17);
            this.lblSoNgayTinhTien.TabIndex = 14;
            this.lblSoNgayTinhTien.Text = "Số ngày tính tiền:";
            // 
            // txtSoNgayTinhTien
            // 
            this.txtSoNgayTinhTien.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoNgayTinhTien.Location = new System.Drawing.Point(380, 277);
            this.txtSoNgayTinhTien.Name = "txtSoNgayTinhTien";
            this.txtSoNgayTinhTien.Size = new System.Drawing.Size(80, 25);
            this.txtSoNgayTinhTien.TabIndex = 15;
            this.txtSoNgayTinhTien.Text = "2";
            // 
            // btnLapHoaDon
            // 
            this.btnLapHoaDon.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLapHoaDon.Location = new System.Drawing.Point(490, 274);
            this.btnLapHoaDon.Name = "btnLapHoaDon";
            this.btnLapHoaDon.Size = new System.Drawing.Size(120, 30);
            this.btnLapHoaDon.TabIndex = 16;
            this.btnLapHoaDon.Text = "Lập hóa đơn";
            this.btnLapHoaDon.UseVisualStyleBackColor = true;
            this.btnLapHoaDon.Click += new System.EventHandler(this.btnLapHoaDon_Click);
            // 
            // dgvHoaDon
            // 
            this.dgvHoaDon.AllowUserToAddRows = false;
            this.dgvHoaDon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHoaDon.BackgroundColor = System.Drawing.Color.White;
            this.dgvHoaDon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoaDon.Location = new System.Drawing.Point(30, 320);
            this.dgvHoaDon.Name = "dgvHoaDon";
            this.dgvHoaDon.ReadOnly = true;
            this.dgvHoaDon.Size = new System.Drawing.Size(840, 180);
            this.dgvHoaDon.TabIndex = 17;
            // 
            // lblHinhThuc
            // 
            this.lblHinhThuc.AutoSize = true;
            this.lblHinhThuc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHinhThuc.Location = new System.Drawing.Point(30, 520);
            this.lblHinhThuc.Name = "lblHinhThuc";
            this.lblHinhThuc.Size = new System.Drawing.Size(66, 17);
            this.lblHinhThuc.TabIndex = 18;
            this.lblHinhThuc.Text = "Hình thức:";
            // 
            // txtHinhThuc
            // 
            this.txtHinhThuc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHinhThuc.Location = new System.Drawing.Point(105, 517);
            this.txtHinhThuc.Name = "txtHinhThuc";
            this.txtHinhThuc.Size = new System.Drawing.Size(125, 25);
            this.txtHinhThuc.TabIndex = 19;
            this.txtHinhThuc.Text = "Thẻ";
            // 
            // lblSoTienThanhToan
            // 
            this.lblSoTienThanhToan.AutoSize = true;
            this.lblSoTienThanhToan.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoTienThanhToan.Location = new System.Drawing.Point(255, 520);
            this.lblSoTienThanhToan.Name = "lblSoTienThanhToan";
            this.lblSoTienThanhToan.Size = new System.Drawing.Size(51, 17);
            this.lblSoTienThanhToan.TabIndex = 20;
            this.lblSoTienThanhToan.Text = "Số tiền:";
            // 
            // txtSoTienThanhToan
            // 
            this.txtSoTienThanhToan.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoTienThanhToan.Location = new System.Drawing.Point(312, 517);
            this.txtSoTienThanhToan.Name = "txtSoTienThanhToan";
            this.txtSoTienThanhToan.Size = new System.Drawing.Size(110, 25);
            this.txtSoTienThanhToan.TabIndex = 21;
            this.txtSoTienThanhToan.Text = "1200000";
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThanhToan.Location = new System.Drawing.Point(455, 514);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(120, 32);
            this.btnThanhToan.TabIndex = 22;
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // btnHoanTatTraPhong
            // 
            this.btnHoanTatTraPhong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoanTatTraPhong.Location = new System.Drawing.Point(595, 514);
            this.btnHoanTatTraPhong.Name = "btnHoanTatTraPhong";
            this.btnHoanTatTraPhong.Size = new System.Drawing.Size(155, 32);
            this.btnHoanTatTraPhong.TabIndex = 23;
            this.btnHoanTatTraPhong.Text = "Hoàn tất trả phòng";
            this.btnHoanTatTraPhong.UseVisualStyleBackColor = true;
            this.btnHoanTatTraPhong.Click += new System.EventHandler(this.btnHoanTatTraPhong_Click);
            // 
            // FrmTraPhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 565);
            this.Controls.Add(this.btnHoanTatTraPhong);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.txtSoTienThanhToan);
            this.Controls.Add(this.lblSoTienThanhToan);
            this.Controls.Add(this.txtHinhThuc);
            this.Controls.Add(this.lblHinhThuc);
            this.Controls.Add(this.dgvHoaDon);
            this.Controls.Add(this.btnLapHoaDon);
            this.Controls.Add(this.txtSoNgayTinhTien);
            this.Controls.Add(this.lblSoNgayTinhTien);
            this.Controls.Add(this.txtSoHoaDon);
            this.Controls.Add(this.lblSoHoaDon);
            this.Controls.Add(this.btnLapPhieuDenBu);
            this.Controls.Add(this.txtSoTienDenBu);
            this.Controls.Add(this.lblSoTienDenBu);
            this.Controls.Add(this.txtMucDo);
            this.Controls.Add(this.lblMucDo);
            this.Controls.Add(this.txtSoPhieuDenBu);
            this.Controls.Add(this.lblSoPhieuDenBu);
            this.Controls.Add(this.dgvTienNghiDenBu);
            this.Controls.Add(this.dgvTienNghi);
            this.Controls.Add(this.dgvPhong);
            this.Controls.Add(this.txtPhieuDangO);
            this.Controls.Add(this.lblPhieuDangO);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FrmTraPhong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trả phòng - Đền bù - Hóa đơn - Thanh toán";
            this.Load += new System.EventHandler(this.FrmTraPhong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNghi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNghiDenBu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPhieuDangO;
        private System.Windows.Forms.TextBox txtPhieuDangO;
        private System.Windows.Forms.DataGridView dgvPhong;
        private System.Windows.Forms.DataGridView dgvTienNghi;
        private System.Windows.Forms.DataGridView dgvTienNghiDenBu;
        private System.Windows.Forms.Label lblSoPhieuDenBu;
        private System.Windows.Forms.TextBox txtSoPhieuDenBu;
        private System.Windows.Forms.Label lblMucDo;
        private System.Windows.Forms.TextBox txtMucDo;
        private System.Windows.Forms.Label lblSoTienDenBu;
        private System.Windows.Forms.TextBox txtSoTienDenBu;
        private System.Windows.Forms.Button btnLapPhieuDenBu;
        private System.Windows.Forms.Label lblSoHoaDon;
        private System.Windows.Forms.TextBox txtSoHoaDon;
        private System.Windows.Forms.Label lblSoNgayTinhTien;
        private System.Windows.Forms.TextBox txtSoNgayTinhTien;
        private System.Windows.Forms.Button btnLapHoaDon;
        private System.Windows.Forms.DataGridView dgvHoaDon;
        private System.Windows.Forms.Label lblHinhThuc;
        private System.Windows.Forms.TextBox txtHinhThuc;
        private System.Windows.Forms.Label lblSoTienThanhToan;
        private System.Windows.Forms.TextBox txtSoTienThanhToan;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnHoanTatTraPhong;
    }
}