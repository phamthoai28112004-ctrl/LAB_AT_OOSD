﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmPhongTienNghi : Form
    {
        private enum TabHienTai { Phong, TienNghi, LapDat }
        private TabHienTai _tabActive = TabHienTai.Phong;
        private readonly PhongTienNghiService _service = new PhongTienNghiService();

        public FrmPhongTienNghi()
        {
            InitializeComponent();
        }

        private void FrmPhongTienNghi_Load(object sender, EventArgs e)
        {
            ChuyenTab(TabHienTai.Phong);
        }

        private void NavButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn == btnNavPhong) ChuyenTab(TabHienTai.Phong);
            else if (btn == btnNavTienNghi) ChuyenTab(TabHienTai.TienNghi);
            else if (btn == btnNavLapDat) ChuyenTab(TabHienTai.LapDat);
        }

        private void ChuyenTab(TabHienTai tab)
        {
            _tabActive = tab;
            ResetNavButtons();

            switch (tab)
            {
                case TabHienTai.Phong:
                    btnNavPhong.Font = new Font(btnNavPhong.Font, FontStyle.Bold);
                    pnlTopInput.Visible = true;
                    pnlBottomInput.Visible = true;
                    dgvPhongTienNghi.Height = 250;
                    TaiDanhSachPhong();
                    break;

                case TabHienTai.TienNghi:
                    btnNavTienNghi.Font = new Font(btnNavTienNghi.Font, FontStyle.Bold);
                    pnlTopInput.Visible = false;
                    pnlBottomInput.Visible = false;
                    dgvPhongTienNghi.Height = 350;
                    TaiDanhSachTienNghi();
                    break;

                case TabHienTai.LapDat:
                    btnNavLapDat.Font = new Font(btnNavLapDat.Font, FontStyle.Bold);
                    pnlTopInput.Visible = false;
                    pnlBottomInput.Visible = true;
                    dgvPhongTienNghi.Height = 250;
                    TaiDanhSachLapDat();
                    break;
            }
        }

        private void ResetNavButtons()
        {
            Font regularFont = new Font("Segoe UI", 10F, FontStyle.Regular);
            btnNavPhong.Font = regularFont;
            btnNavTienNghi.Font = regularFont;
            btnNavLapDat.Font = regularFont;
        }

        private void TaiDanhSachPhong()
        {
            try
            {
                DataTable dt = _service.LayDanhSachPhong();
                dgvPhongTienNghi.DataSource = dt;

                // Cấu hình tiêu đề cột
                if (dgvPhongTienNghi.Columns["Phong"] != null) dgvPhongTienNghi.Columns["Phong"].HeaderText = "Phòng";
                if (dgvPhongTienNghi.Columns["Khu"] != null) dgvPhongTienNghi.Columns["Khu"].HeaderText = "Khu";
                if (dgvPhongTienNghi.Columns["SucChua"] != null) dgvPhongTienNghi.Columns["SucChua"].HeaderText = "Sức chứa";
                if (dgvPhongTienNghi.Columns["DonGia"] != null) dgvPhongTienNghi.Columns["DonGia"].HeaderText = "Đơn giá";
                if (dgvPhongTienNghi.Columns["TrangThai"] != null) dgvPhongTienNghi.Columns["TrangThai"].HeaderText = "Trạng thái";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách phòng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TaiDanhSachTienNghi()
        {
            try
            {
                DataTable dt = _service.LayDanhSachTienNghi();
                dgvPhongTienNghi.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách tiện nghi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TaiDanhSachLapDat()
        {
            try
            {
                DataTable dt = _service.LayDanhSachLapDat();
                dgvPhongTienNghi.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải lịch sử lắp đặt: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLapPhieu_Click(object sender, EventArgs e)
        {
            string maPhieu = txtPhieuLapDat.Text.Trim();
            string maTN = txtTienNghi.Text.Trim();
            string maPhong = txtPhongBottom.Text.Trim();
            string tinhTrang = txtTinhTrang.Text.Trim();

            if (string.IsNullOrEmpty(maPhieu) || string.IsNullOrEmpty(maTN) || string.IsNullOrEmpty(maPhong))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Mã phiếu, Tiện nghi và Phòng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_service.LapPhieuLapDat(maPhieu, maTN, maPhong, tinhTrang))
            {
                MessageBox.Show("Lập phiếu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (_tabActive == TabHienTai.LapDat)
                {
                    TaiDanhSachLapDat();
                }
            }
            else
            {
                MessageBox.Show("Lập phiếu thất bại. Kiểm tra lại thông tin phòng hoặc tiện nghi!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvPhongTienNghi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvPhongTienNghi.Rows[e.RowIndex];

                if (_tabActive == TabHienTai.Phong)
                {
                    txtSoPhong.Text = row.Cells["Phong"].Value?.ToString();
                    txtPhongBottom.Text = row.Cells["Phong"].Value?.ToString();
                    txtKhuVuc.Text = row.Cells["Khu"].Value?.ToString();
                    txtSoNguoiToiDa.Text = row.Cells["SucChua"].Value?.ToString();
                    txtDonGiaNgay.Text = row.Cells["DonGia"].Value?.ToString();
                }
            }
        }
    }
}