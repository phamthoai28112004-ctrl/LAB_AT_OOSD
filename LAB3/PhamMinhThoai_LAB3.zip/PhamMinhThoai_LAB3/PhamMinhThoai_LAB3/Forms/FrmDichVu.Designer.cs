﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmDichVu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPhieuLuuTru = new System.Windows.Forms.Label();
            this.txtPhieuLuuTru = new System.Windows.Forms.TextBox();
            this.lblPhong = new System.Windows.Forms.Label();
            this.txtPhong = new System.Windows.Forms.TextBox();
            this.lblDichVu = new System.Windows.Forms.Label();
            this.txtDichVu = new System.Windows.Forms.TextBox();
            this.lblNgaySuDung = new System.Windows.Forms.Label();
            this.txtNgaySuDung = new System.Windows.Forms.TextBox();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.btnGhiNhan = new System.Windows.Forms.Button();
            this.dgvSuDungDV = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuDungDV)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPhieuLuuTru
            // 
            this.lblPhieuLuuTru.AutoSize = true;
            this.lblPhieuLuuTru.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhieuLuuTru.Location = new System.Drawing.Point(30, 25);
            this.lblPhieuLuuTru.Name = "lblPhieuLuuTru";
            this.lblPhieuLuuTru.Size = new System.Drawing.Size(84, 17);
            this.lblPhieuLuuTru.TabIndex = 0;
            this.lblPhieuLuuTru.Text = "Phiếu lưu trú:";
            // 
            // txtPhieuLuuTru
            // 
            this.txtPhieuLuuTru.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhieuLuuTru.Location = new System.Drawing.Point(125, 22);
            this.txtPhieuLuuTru.Name = "txtPhieuLuuTru";
            this.txtPhieuLuuTru.Size = new System.Drawing.Size(180, 25);
            this.txtPhieuLuuTru.TabIndex = 1;
            this.txtPhieuLuuTru.Text = "DP001";
            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhong.Location = new System.Drawing.Point(330, 25);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(48, 17);
            this.lblPhong.TabIndex = 2;
            this.lblPhong.Text = "Phòng:";
            // 
            // txtPhong
            // 
            this.txtPhong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhong.Location = new System.Drawing.Point(385, 22);
            this.txtPhong.Name = "txtPhong";
            this.txtPhong.Size = new System.Drawing.Size(130, 25);
            this.txtPhong.TabIndex = 3;
            this.txtPhong.Text = "A101";
            // 
            // lblDichVu
            // 
            this.lblDichVu.AutoSize = true;
            this.lblDichVu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDichVu.Location = new System.Drawing.Point(540, 25);
            this.lblDichVu.Name = "lblDichVu";
            this.lblDichVu.Size = new System.Drawing.Size(54, 17);
            this.lblDichVu.TabIndex = 4;
            this.lblDichVu.Text = "Dịch vụ:";
            // 
            // txtDichVu
            // 
            this.txtDichVu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDichVu.Location = new System.Drawing.Point(605, 22);
            this.txtDichVu.Name = "txtDichVu";
            this.txtDichVu.Size = new System.Drawing.Size(220, 25);
            this.txtDichVu.TabIndex = 5;
            this.txtDichVu.Text = "Ăn sáng";
            // 
            // lblNgaySuDung
            // 
            this.lblNgaySuDung.AutoSize = true;
            this.lblNgaySuDung.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgaySuDung.Location = new System.Drawing.Point(25, 68);
            this.lblNgaySuDung.Name = "lblNgaySuDung";
            this.lblNgaySuDung.Size = new System.Drawing.Size(94, 17);
            this.lblNgaySuDung.TabIndex = 6;
            this.lblNgaySuDung.Text = "Ngày sử dụng:";
            // 
            // txtNgaySuDung
            // 
            this.txtNgaySuDung.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgaySuDung.Location = new System.Drawing.Point(125, 65);
            this.txtNgaySuDung.Name = "txtNgaySuDung";
            this.txtNgaySuDung.Size = new System.Drawing.Size(180, 25);
            this.txtNgaySuDung.TabIndex = 7;
            this.txtNgaySuDung.Text = "12/09/2026";
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoLuong.Location = new System.Drawing.Point(315, 68);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(64, 17);
            this.lblSoLuong.TabIndex = 8;
            this.lblSoLuong.Text = "Số lượng:";
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuong.Location = new System.Drawing.Point(385, 65);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(130, 25);
            this.txtSoLuong.TabIndex = 9;
            this.txtSoLuong.Text = "2";
            // 
            // btnGhiNhan
            // 
            this.btnGhiNhan.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGhiNhan.Location = new System.Drawing.Point(605, 61);
            this.btnGhiNhan.Name = "btnGhiNhan";
            this.btnGhiNhan.Size = new System.Drawing.Size(180, 32);
            this.btnGhiNhan.TabIndex = 10;
            this.btnGhiNhan.Text = "Ghi nhận";
            this.btnGhiNhan.UseVisualStyleBackColor = true;
            this.btnGhiNhan.Click += new System.EventHandler(this.btnGhiNhan_Click);
            // 
            // dgvSuDungDV
            // 
            this.dgvSuDungDV.AllowUserToAddRows = false;
            this.dgvSuDungDV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSuDungDV.BackgroundColor = System.Drawing.Color.White;
            this.dgvSuDungDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSuDungDV.Location = new System.Drawing.Point(23, 115);
            this.dgvSuDungDV.Name = "dgvSuDungDV";
            this.dgvSuDungDV.ReadOnly = true;
            this.dgvSuDungDV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSuDungDV.Size = new System.Drawing.Size(810, 340);
            this.dgvSuDungDV.TabIndex = 11;
            // 
            // FrmDichVu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(858, 480);
            this.Controls.Add(this.dgvSuDungDV);
            this.Controls.Add(this.btnGhiNhan);
            this.Controls.Add(this.txtSoLuong);
            this.Controls.Add(this.lblSoLuong);
            this.Controls.Add(this.txtNgaySuDung);
            this.Controls.Add(this.lblNgaySuDung);
            this.Controls.Add(this.txtDichVu);
            this.Controls.Add(this.lblDichVu);
            this.Controls.Add(this.txtPhong);
            this.Controls.Add(this.lblPhong);
            this.Controls.Add(this.txtPhieuLuuTru);
            this.Controls.Add(this.lblPhieuLuuTru);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FrmDichVu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sử dụng dịch vụ";
            this.Load += new System.EventHandler(this.FrmDichVu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuDungDV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPhieuLuuTru;
        private System.Windows.Forms.TextBox txtPhieuLuuTru;
        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.TextBox txtPhong;
        private System.Windows.Forms.Label lblDichVu;
        private System.Windows.Forms.TextBox txtDichVu;
        private System.Windows.Forms.Label lblNgaySuDung;
        private System.Windows.Forms.TextBox txtNgaySuDung;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.Button btnGhiNhan;
        private System.Windows.Forms.DataGridView dgvSuDungDV;
    }
}