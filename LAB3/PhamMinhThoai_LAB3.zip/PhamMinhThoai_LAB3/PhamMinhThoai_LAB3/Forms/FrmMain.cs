﻿using System;
using System.Windows.Forms;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        // 1. Mở màn hình Danh mục
        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            FrmDanhMuc frm = new FrmDanhMuc();
            frm.ShowDialog();
        }

        // 2. Mở màn hình Phòng - Tiện nghi
        private void btnPhongTienNghi_Click(object sender, EventArgs e)
        {
            FrmPhongTienNghi frm = new FrmPhongTienNghi();
            frm.ShowDialog();
        }

        // 3. Mở màn hình Đặt / Nhận phòng (Khớp với FrmDatPhong.cs)
        private void btnDatNhanPhong_Click(object sender, EventArgs e)
        {
            FrmDatPhong frm = new FrmDatPhong();
            frm.ShowDialog();
        }

        // 4. Mở màn hình Sử dụng dịch vụ (Khớp với FrmDichVu.cs)
        private void btnSuDungDichVu_Click(object sender, EventArgs e)
        {
            FrmDichVu frm = new FrmDichVu();
            frm.ShowDialog();
        }

        // 5. Mở màn hình Trả phòng - Thanh toán (Khớp với FrmTraPhong.cs)
        private void btnTraPhongThanhToan_Click(object sender, EventArgs e)
        {
            FrmTraPhong frm = new FrmTraPhong();
            frm.ShowDialog();
        }

        // 6. Mở màn hình Thống kê (Khớp với FrmThongKe.cs)
        private void btnThongKe_Click(object sender, EventArgs e)
        {
            FrmThongKe frm = new FrmThongKe();
            frm.ShowDialog();
        }

        // 7. Nút Thoát
        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Xác nhận khi đóng Form chính
        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}